﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Roles;
using VotingApplication.Accessors.UserRoles;
using VotingApplication.Accessors.Users;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Users
{
    public class UserManager : IUserManager
    {
        private readonly IUserAccessor _userAccessor;
        private readonly IRoleAccessor _roleAccessor;
        private readonly IUserRoleAccessor _userRoleAccessor;

        public UserManager(
            IUserAccessor userAccessor, 
            IRoleAccessor roleAccessor,
            IUserRoleAccessor userRoleAccessor)
        {
            _userAccessor = userAccessor;
            _roleAccessor = roleAccessor;
            _userRoleAccessor = userRoleAccessor;
        }

        public UserViewModel DefaultView()
        {
            var view = new UserViewModel();

            try
            {
                view.Users = _userAccessor.Get();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public UserUpdateViewModel UpdateView(int userId)
        {
            var view = new UserUpdateViewModel();

            try
            {
                if (userId != 0)
                {
                    var user = _userAccessor.Find(userId);

                    view.UserId = user.UserId;
                    view.FirstName = user.FirstName;
                    view.LastName = user.LastName;
                    view.Username = user.Username;
                    view.Password = user.Password;
                }
                else
                {
                    view.UserId = 0;
                    view.FirstName = "";
                    view.LastName = "";
                    view.Username = "";
                    view.Password = "";
                }

                view.Roles = GetRoles(view.UserId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Save(User user)
        {
            bool successful;

            try
            {
                successful = _userAccessor.Save(user);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public int Find(string username)
        {
            int id;

            try
            {
                id = _userAccessor.Find(username).UserId;
            }
            catch (Exception ex)
            {
                id = 0;
            }

            return id;
        }

        public bool Delete(int userId)
        {
            bool successful;

            try
            {
                successful = _userAccessor.Delete(userId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Exists(int userId, string username)
        {
            bool exists;

            try
            {
                exists = _userAccessor.Exists(userId, username);
            }
            catch (Exception ex)
            {
                exists = false;
            }

            return exists;
        }

        public bool DeleteRoles(int userId)
        {
            bool successful;

            try
            {
                successful = _userRoleAccessor.Delete(userId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool SaveRole(int userId, int roleId)
        {
            bool successful;

            try
            {
                successful = _userRoleAccessor.Insert(userId, roleId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public List<RoleListItem> GetRoles(int userId)
        {
            var user = _userAccessor.Find(userId);
            List<int> selectedIds = new List<int>();
            foreach (var role in user.Roles)
                selectedIds.Add(role.RoleId);

            return GetSelectedRoles(selectedIds);
        }

        public List<RoleListItem> GetSelectedRoles(List<int> selectedIds)
        {
            var roles = _roleAccessor.Get();
            List<RoleListItem> lstItems = new List<RoleListItem>();
            foreach (var role in roles)
            {
                if (selectedIds.Contains(role.RoleId))
                    lstItems.Add(new RoleListItem() { Role = role, Selected = true });
                else
                    lstItems.Add(new RoleListItem() { Role = role, Selected = false });
            }
            
            return lstItems;
        }

    }
}