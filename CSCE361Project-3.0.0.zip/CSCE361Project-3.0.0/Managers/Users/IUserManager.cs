﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Users
{
    public interface IUserManager
    {
        UserViewModel DefaultView();
        UserUpdateViewModel UpdateView(int userId);
        bool Save(User user);
        int Find(string username);
        bool Delete(int userId);
        bool Exists(int userId, string username);
        bool DeleteRoles(int userId);
        bool SaveRole(int userId, int roleId);
        List<RoleListItem> GetRoles(int userId);
        List<RoleListItem> GetSelectedRoles(List<int> selectedIds);
    }
}
