﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.Accessors.Users;
using VotingApplication.Models;

namespace VotingApplication.Managers.VoterVoted
{
    public class VoterVotedManager : IVoterVotedManager
    {
        private readonly IElectionAccessor _electionAccessor;
        private readonly IUserAccessor _userAccessor;
        private readonly IElectionVoteAccessor _electionVoteAccessor;
        private readonly IIssueVoteAccessor _issueVoteAccessor;

        public VoterVotedManager(
            IElectionAccessor electionAccessor, 
            IUserAccessor userAccessor,
            IElectionVoteAccessor electionVoteAccessor,
            IIssueVoteAccessor issueVoteAccessor)
        {
            _electionAccessor = electionAccessor;
            _userAccessor = userAccessor;
            _electionVoteAccessor = electionVoteAccessor;
            _issueVoteAccessor = issueVoteAccessor;
        }

        public VoterVotedViewModel DefaultView(int electionId)
        {
            var view = new VoterVotedViewModel();

            try
            {
                view.Elections = _electionAccessor.Get();
                if (electionId == 0)
                    view.ElectionId = view.Elections[0].ElectionId;
                else
                    view.ElectionId = electionId;
                view.DetailViewModel = DetailView(view.ElectionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public VoterVotedDetailViewModel DetailView(int electionId)
        {
            var view = new VoterVotedDetailViewModel();

            try
            {
                view.ElectionId = electionId;

                var lst0 = _userAccessor.Get();
                foreach (var user in lst0)
                {
                    var lst1 = _electionVoteAccessor.Get(user.UserId, electionId);
                    var lst2 = _issueVoteAccessor.Get(user.UserId, electionId);

                    if (lst1.Count > 0 || lst2.Count > 0)
                        view.UserVotedListItems.Add(new UserVotedListItem()
                        {
                            UserName = user.FirstName + " " + user.LastName,
                            Voted = true
                        });
                    else
                        view.UserVotedListItems.Add(new UserVotedListItem()
                        {
                            UserName = user.FirstName + " " + user.LastName,
                            Voted = false
                        });
                }

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
    }
}