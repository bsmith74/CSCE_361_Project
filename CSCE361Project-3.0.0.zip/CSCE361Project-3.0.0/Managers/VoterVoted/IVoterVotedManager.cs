﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.Models;

namespace VotingApplication.Managers.VoterVoted
{
    public interface IVoterVotedManager
    {
        VoterVotedViewModel DefaultView(int electionId);
        VoterVotedDetailViewModel DetailView(int electionId);
    }
}
