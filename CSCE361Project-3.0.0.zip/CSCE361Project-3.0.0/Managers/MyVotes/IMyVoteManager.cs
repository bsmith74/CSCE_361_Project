﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.Models;

namespace VotingApplication.Managers.MyVotes
{
    public interface IMyVoteManager
    {
        MyVotesViewModel DefaultView(int userId, int electionId);
        MyVotesDetailViewModel DetailView(int userId, int electionId);
    }
}
