﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.Models;

namespace VotingApplication.Managers.MyVotes
{
    public class MyVoteManager : IMyVoteManager
    {
        private readonly IElectionVoteAccessor _electionVoteAccessor;
        private readonly IIssueVoteAccessor _issueVoteAccessor;
        private readonly IElectionAccessor _electionAccessor;

        public MyVoteManager(IElectionVoteAccessor electionVoteAccessor, IIssueVoteAccessor issueVoteAccessor, IElectionAccessor electionAccessor)
        {
            _electionVoteAccessor = electionVoteAccessor;
            _issueVoteAccessor = issueVoteAccessor;
            _electionAccessor = electionAccessor;
        }

        public MyVotesViewModel DefaultView(int userId, int electionId)
        {
            var view = new MyVotesViewModel();

            try
            {
                view.UserId = userId;

                view.Elections = _electionAccessor.Get();
                if (electionId == 0)
                    view.ElectionId = view.Elections[0].ElectionId;
                else
                    view.ElectionId = electionId;

                view.DetailViewModel = DetailView(view.UserId, view.ElectionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public MyVotesDetailViewModel DetailView(int userId, int electionId)
        {
            var view = new MyVotesDetailViewModel();

            try
            {
                view.UserId = userId;
                view.ElectionId = electionId;
                view.ElectionVotes = _electionVoteAccessor.Get(userId, electionId);
                view.IssueVotes = _issueVoteAccessor.Get(userId, electionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
    }
}