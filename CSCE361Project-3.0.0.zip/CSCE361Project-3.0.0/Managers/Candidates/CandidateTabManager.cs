﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.CandidatePositions;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.Candidates;
using VotingApplication.Models;
using VotingApplication.DataContracts;

namespace VotingApplication.Managers.Candidates
{
    public class CandidateTabManager : ICandidateTabManager
    {
        private readonly IElectionAccessor _electionAccessor;
        private readonly ICandidatePositionAccessor _candidatePositionAccessor;
        private readonly ICandidateAccessor _candidateAccessor;

        public CandidateTabManager(IElectionAccessor electionAccessor, ICandidatePositionAccessor candidatePositionAccessor, ICandidateAccessor candidateAccessor)
        {
            _electionAccessor = electionAccessor;
            _candidatePositionAccessor = candidatePositionAccessor;
            _candidateAccessor = candidateAccessor;
        }

        public CandidateTabViewModel DefaultView()
        {
            var view = new CandidateTabViewModel();

            try
            {
                var election = _electionAccessor.FindCurrent(DateTime.Now);
                view.ElectionId = election.ElectionId;

                if (election.ElectionId != 0)
                {
                    view.ElectionName = election.Name;

                    var lst = _candidatePositionAccessor.GetOrderedByCandidate(election.ElectionId);

                    if (lst.Count > 0)
                        view.Candidates = GetCandidatePositions(lst);
                }

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        private List<CandidateTabListItem> GetCandidatePositions(List<CandidatePosition> lst)
        {
            List<CandidateTabListItem> items = new List<CandidateTabListItem>();

            if (lst.Count > 0)
            {
                int prevCandidate = 0;
                int currCandidate = lst[0].CandidateId;

                // create and initialize first tab item
                var lstItem = new CandidateTabListItem();
                lstItem.Candidate = _candidateAccessor.Find(lst[0].CandidateId);
                lstItem.Positions.Add(new Position() { Name = lst[0].PositionName, PositionId = lst[0].PositionId });

                // loop through all other items in lst
                for (int i = 1; i < lst.Count; i++)
                {
                    prevCandidate = currCandidate;
                    currCandidate = lst[i].CandidateId;

                    // current candidate same as previous candidate, add position to current tab item
                    if (prevCandidate == currCandidate)
                        lstItem.Positions.Add(new Position() { Name = lst[i].PositionName, PositionId = lst[i].PositionId });
                    else
                    {
                        // current candidate is different than previous candidate, create and initialize new tab item
                        items.Add(lstItem);

                        lstItem = new CandidateTabListItem();

                        lstItem.Candidate = _candidateAccessor.Find(lst[i].CandidateId);
                        lstItem.Positions.Add(new Position() { Name = lst[i].PositionName, PositionId = lst[i].PositionId });
                    }
                }

                // add last table item
                items.Add(lstItem);
            }

            return items;
        }
    }
}