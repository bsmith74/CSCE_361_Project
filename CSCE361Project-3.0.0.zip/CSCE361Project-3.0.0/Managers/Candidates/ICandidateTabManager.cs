﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.Models;

namespace VotingApplication.Managers.Candidates
{
    public interface ICandidateTabManager
    {
        CandidateTabViewModel DefaultView();
    }
}