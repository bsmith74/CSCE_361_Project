﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Candidates
{
    public interface ICandidateManager
    {
        CandidateViewModel DefaultView();
        CandidateUpdateViewModel UpdateView(int candidateId);
        bool Save(Candidate candidate);
        bool Delete(int candidateId);
        bool Exists(int candidateId, string first, string last);
        List<Party> GetParties();
    }
}
