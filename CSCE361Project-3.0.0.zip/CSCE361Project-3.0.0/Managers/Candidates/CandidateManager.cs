﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Candidates;
using VotingApplication.Accessors.Parties;
using VotingApplication.Accessors.Users;
using VotingApplication.DataContracts;
using VotingApplication.Models;


namespace VotingApplication.Managers.Candidates
{
    public class CandidateManager : ICandidateManager
    {
        private readonly ICandidateAccessor _candidateAccessor;
        private readonly IPartyAccessor _partyAccessor;

        public CandidateManager(ICandidateAccessor candidateAccessor, IPartyAccessor partyAccessor)
        {
            _candidateAccessor = candidateAccessor;
            _partyAccessor = partyAccessor;
        }

        public CandidateViewModel DefaultView()
        {
            var view = new CandidateViewModel();

            try
            {
                view.Candidates = _candidateAccessor.Get();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public CandidateUpdateViewModel UpdateView(int candidateId)
        {
            var view = new CandidateUpdateViewModel();

            try
            {
                if (candidateId != 0)
                {
                    var candidate = _candidateAccessor.Find(candidateId);

                    view.CandidateId = candidate.CandidateId;
                    view.FirstName = candidate.FirstName;
                    view.LastName = candidate.LastName;
                    view.Description = candidate.Description;
                    view.PartyId = candidate.PartyId;
                    view.PartyName = candidate.PartyName;
                }
                else
                {
                    view.CandidateId = 0;
                    view.FirstName = "";
                    view.LastName = "";
                    view.Description = "";
                    view.PartyId = 0;
                    view.PartyName = "";
                }

                view.Parties = GetParties();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Save(Candidate candidate)
        {
            bool successful;

            try
            {
                successful = _candidateAccessor.Save(candidate);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Delete(int candidateId)
        {
            bool successful;

            try
            {
                successful = _candidateAccessor.Delete(candidateId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Exists(int candidateId, string first, string last)
        {
            bool exists = false;

            try
            {
                exists = _candidateAccessor.Exists(candidateId, first, last);
            }
            catch (Exception ex)
            {
                exists = false;
            }

            return exists;
        }

        public List<Party> GetParties()
        {
            return _partyAccessor.Get();
        }
    }
}