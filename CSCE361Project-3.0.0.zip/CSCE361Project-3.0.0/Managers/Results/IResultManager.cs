﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.Models;

namespace VotingApplication.Managers.Results
{
    public interface IResultManager
    {
        ResultViewModel DefaultView(int electionId);
        ResultDetailViewModel DetailView(int electionId);
    }
}
