﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Results;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.Positions;
using VotingApplication.Models;

namespace VotingApplication.Managers.Results
{
    public class ResultManager : IResultManager
    {
        private readonly IResultAccessor _resultAccessor;
        private readonly IElectionAccessor _electionAccessor;
        private readonly IPositionAccessor _positionAccessor;


        public ResultManager(IResultAccessor resultAccessor, IElectionAccessor electionAccessor, PositionAccessor positionAccessor)
        {
            _resultAccessor = resultAccessor;
            _electionAccessor = electionAccessor;
            _positionAccessor = positionAccessor;
        }

        public ResultViewModel DefaultView(int electionId)
        {
            var view = new ResultViewModel();

            try
            {

                view.Elections = _electionAccessor.GetFinished();
                if (electionId == 0)
                    view.ElectionId = view.Elections[0].ElectionId;
                else
                    view.ElectionId = electionId;
                    view.DetailViewModel = DetailView(view.ElectionId);


                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public ResultDetailViewModel DetailView(int electionId)
        {
            var view = new ResultDetailViewModel();

            try
            {

                    view.ElectionId = electionId;
                    view.Positions = _positionAccessor.GetElectionPositions(view.ElectionId);
                    view.ElectionResults = _resultAccessor.GetElectionResults(view.ElectionId, view.Positions);
                    view.IssueResults = _resultAccessor.GetIssue(view.ElectionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
    }
}