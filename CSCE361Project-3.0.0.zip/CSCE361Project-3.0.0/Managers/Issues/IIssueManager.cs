﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Issues
{
    public interface IIssueManager
    {
        IssueViewModel DefaultView();
        IssueUpdateViewModel UpdateView(int issueId);
        bool Save(Issue issue);
        bool Delete(int issueId);
        bool Exists(int issueId, string name, string description);
    }
}
