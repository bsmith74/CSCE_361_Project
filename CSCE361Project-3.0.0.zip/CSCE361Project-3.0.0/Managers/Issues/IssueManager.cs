﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Issues;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Issues
{
    public class IssueManager : IIssueManager
    {
        private readonly IIssueAccessor _issueAccessor;

        public IssueManager(IIssueAccessor issueAccessor)
        {
            _issueAccessor = issueAccessor;
        }

        public IssueViewModel DefaultView()
        {
            var view = new IssueViewModel();

            try
            {
                view.Issues = _issueAccessor.Get();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Delete(int issueId)
        {
            bool successful;

            try
            {
                successful = _issueAccessor.Delete(issueId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Save(Issue issue)
        {
            bool successful;

            try
            {
                successful = _issueAccessor.Save(issue);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public IssueUpdateViewModel UpdateView(int issueId)
        {
            var view = new IssueUpdateViewModel();

            try
            {
                if (issueId != 0)
                {
                    var user = _issueAccessor.Find(issueId);

                    view.IssueId = user.IssueId;
                    view.Name = user.Name;
                    view.Description = user.Description;
                }
                else
                {
                    view.IssueId = 0;
                    view.Name = "";
                    view.Description = "";
                }

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Exists(int issueId, string name, string description)
        {
            bool exists;

            try
            {
                exists = _issueAccessor.Exists(issueId, name, description);
            }
            catch (Exception ex)
            {
                exists = false;
            }

            return exists;
        }
    }
}