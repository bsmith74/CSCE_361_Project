﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.ElectionIssues;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.Issues;
using VotingApplication.Models;

namespace VotingApplication.Managers.Issues
{
    public class IssueTabManager : IIssueTabManager
    {
        private readonly IElectionAccessor _electionAccessor;
        private readonly IElectionIssueAccessor _electionIssueAccessor;
        private readonly IIssueAccessor _issueAccessor;

        public IssueTabManager(IElectionAccessor electionAccessor, IElectionIssueAccessor electionIssueAccessor, IIssueAccessor issueAccessor)
        {
            _electionAccessor = electionAccessor;
            _electionIssueAccessor = electionIssueAccessor;
            _issueAccessor = issueAccessor;
        }

        public IssueTabViewModel DefaultView()
        {
            var view = new IssueTabViewModel();

            try
            {
                var election = _electionAccessor.FindCurrent(DateTime.Now);
                view.ElectionId = election.ElectionId;

                if (election.ElectionId != 0)
                {
                    view.ElectionName = election.Name;

                    var lst = _electionIssueAccessor.Get(election.ElectionId);

                    foreach (var issue in lst)
                        view.Issues.Add(_issueAccessor.Find(issue.IssueId));
                }

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
    }
}