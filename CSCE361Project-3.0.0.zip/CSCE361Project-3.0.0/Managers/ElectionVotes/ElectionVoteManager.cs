﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.ElectionVotes
{
    public class ElectionVoteManager : IElectionVoteManager
    {
        private readonly IElectionVoteAccessor _electionVoteAccessor;
        private readonly IElectionAccessor _electionAccessor;

        public ElectionVoteManager(IElectionVoteAccessor electionVoteAccessor, IElectionAccessor electionAccessor)
        {
            _electionVoteAccessor = electionVoteAccessor;
            _electionAccessor = electionAccessor;
        }

        public ElectionVoteViewModel DefaultView(int electionId)
        {
            var view = new ElectionVoteViewModel();

            try
            {
                view.Elections = _electionAccessor.Get();
                if (electionId == 0)
                    view.ElectionId = view.Elections[0].ElectionId;
                else
                    view.ElectionId = electionId;
                view.DetailViewModel = DetailView(view.ElectionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public ElectionVoteDetailViewModel DetailView(int electionId)
        {
            var view = new ElectionVoteDetailViewModel();

            try
            {
                view.ElectionId = electionId;
                view.Votes = _electionVoteAccessor.Get(view.ElectionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Delete(int electionVoteId)
        {
            bool successful;

            try
            {
                successful = _electionVoteAccessor.Delete(electionVoteId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public ElectionVoteDeleteViewModel DeleteView(int electionVoteId)
        {
            var view = new ElectionVoteDeleteViewModel();

            try
            {
                if (electionVoteId != 0)
                {
                    var ev = _electionVoteAccessor.Find(electionVoteId);

                    view.ElectionVoteId = ev.ElectionVoteId;
                    view.PositionId = ev.PositionId;
                    view.ElectionId = ev.ElectionId;
                    view.UserId = ev.UserId;
                    view.UserName = ev.UserName;
                    view.PositionName = ev.PositionName;

                    view.Error = false;
                    view.ErrorMessage = "";
                }
                else
                {
                    view.Error = true;
                    view.ErrorMessage = "Did not find Election Vote record to delete!";
                }
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
    }
}