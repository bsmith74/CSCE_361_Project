﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.ElectionVotes
{
    public interface IElectionVoteManager
    {
        ElectionVoteViewModel DefaultView(int electionId);
        ElectionVoteDetailViewModel DetailView(int electionId);
        ElectionVoteDeleteViewModel DeleteView(int electionVoteId);
        bool Delete(int electionVoteId);
    }
}
