﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.IssueVotes
{
    public interface IIssueVoteManager
    {
        IssueVoteViewModel DefaultView(int electionId);
        IssueVoteDetailViewModel DetailView(int electionId);
        IssueVoteDeleteViewModel DeleteView(int issueVoteId);
        bool Delete(int issueVoteId);
    }
}
