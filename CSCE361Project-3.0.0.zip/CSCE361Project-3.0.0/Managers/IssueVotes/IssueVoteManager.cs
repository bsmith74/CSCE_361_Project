﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.IssueVotes
{
    public class IssueVoteManager : IIssueVoteManager
    {
        private readonly IIssueVoteAccessor _issueVoteAccessor;
        private readonly IElectionAccessor _electionAccessor;

        public IssueVoteManager(IIssueVoteAccessor issueVoteAccessor, IElectionAccessor electionAccessor)
        {
            _issueVoteAccessor = issueVoteAccessor;
            _electionAccessor = electionAccessor;
        }

        public IssueVoteViewModel DefaultView(int electionId)
        {
            var view = new IssueVoteViewModel();

            try
            {
                view.Elections = _electionAccessor.Get();
                if (electionId == 0)
                    view.ElectionId = view.Elections[0].ElectionId;
                else
                    view.ElectionId = electionId;
                view.DetailViewModel = DetailView(view.ElectionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public IssueVoteDetailViewModel DetailView(int electionId)
        {
            var view = new IssueVoteDetailViewModel();

            try
            {
                view.ElectionId = electionId;
                view.Votes = _issueVoteAccessor.Get(view.ElectionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Delete(int issueVoteId)
        {
            bool successful;

            try
            {
                successful = _issueVoteAccessor.Delete(issueVoteId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public IssueVoteDeleteViewModel DeleteView(int issueVoteId)
        {
            var view = new IssueVoteDeleteViewModel();

            try
            {
                if (issueVoteId != 0)
                {
                    var iv = _issueVoteAccessor.Find(issueVoteId);

                    view.IssueVoteId = iv.IssueVoteId;
                    view.IssueId = iv.IssueId;
                    view.IssueName = iv.IssueName;
                    view.Vote = iv.Vote;
                    view.ElectionId = iv.ElectionId;
                    view.UserId = iv.UserId;
                    view.UserName = iv.UserName;

                    view.Error = false;
                    view.ErrorMessage = "";
                }
                else
                {
                    view.Error = true;
                    view.ErrorMessage = "Did not find an issue vote record to delete!";
                }
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
    }
}