﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Roles
{
    public interface IRoleManager
    {
        RoleViewModel DefaultView();
        RoleUpdateViewModel UpdateView(int roleId);
        bool Save(Role role);
        bool Delete(int roleId);
    }
}
