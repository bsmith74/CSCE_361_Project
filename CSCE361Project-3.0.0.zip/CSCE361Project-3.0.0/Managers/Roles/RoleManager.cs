﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Roles;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Roles
{
    public class RoleManager : IRoleManager
    {
        private readonly IRoleAccessor _roleAccessor;

        public RoleManager(IRoleAccessor roleAccessor)
        {
            _roleAccessor = roleAccessor;
        }

        public RoleViewModel DefaultView()
        {
            var view = new RoleViewModel();

            try
            {
                view.Roles = _roleAccessor.Get();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Delete(int roleId)
        {
            bool successful;

            try
            {
                successful = _roleAccessor.Delete(roleId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Save(Role role)
        {
            bool successful;

            try
            {
                successful = _roleAccessor.Save(role);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public RoleUpdateViewModel UpdateView(int roleId)
        {
            var view = new RoleUpdateViewModel();

            try
            {
                if (roleId != 0)
                {
                    var role = _roleAccessor.Find(roleId);

                    view.RoleId = role.RoleId;
                    view.Name = role.Name;
                }
                else
                {
                    view.RoleId = 0;
                    view.Name = "";
                }

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
    }
}