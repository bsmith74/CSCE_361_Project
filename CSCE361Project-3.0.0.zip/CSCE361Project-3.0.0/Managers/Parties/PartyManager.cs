﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Parties;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Parties
{
    public class PartyManager : IPartyManager
    {
        private readonly IPartyAccessor _partyAccessor;

        public PartyManager(IPartyAccessor partyAccessor)
        {
            _partyAccessor = partyAccessor;
        }

        public PartyViewModel DefaultView()
        {
            var view = new PartyViewModel();

            try
            {
                view.Parties = _partyAccessor.Get();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Delete(int partyId)
        {
            bool successful;

            try
            {
                successful = _partyAccessor.Delete(partyId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Exists(int partyId, string name)
        {
            bool exists = false;

            try
            {
                exists = _partyAccessor.Exists(partyId, name);
            }
            catch (Exception ex)
            {
                exists = false;
            }

            return exists;
        }

        public bool Save(Party party)
        {
            bool successful;

            try
            {
                successful = _partyAccessor.Save(party);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public PartyUpdateViewModel UpdateView(int partyId)
        {
            var view = new PartyUpdateViewModel();

            try
            {
                if (partyId != 0)
                {
                    var user = _partyAccessor.Find(partyId);

                    view.PartyId = user.PartyId;
                    view.Name = user.Name;
                }
                else
                {
                    view.PartyId = 0;
                    view.Name = "";
                }

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
    }
}