﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Parties
{
    public interface IPartyManager
    {
        PartyViewModel DefaultView();
        PartyUpdateViewModel UpdateView(int partyId);
        bool Save(Party party);
        bool Delete(int partyId);
        bool Exists(int partyId, string name);
    }
}