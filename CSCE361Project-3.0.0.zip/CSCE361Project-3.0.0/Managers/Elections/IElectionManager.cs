﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Elections
{
    public interface IElectionManager
    {
        ElectionViewModel DefaultView();
        ElectionUpdateViewModel UpdateView(int electionId);
        bool Save(Election election);
        bool Delete(int electionId);
        bool Exists(int electionId, DateTime startDate, DateTime endDate);
        CandidatePositionViewModel CandidatesView(int electionId);
        CandidatePositionUpdateViewModel CandidateUpdateView(int electionId, int candidateId);
        bool SaveCandidate(CandidatePosition cp);
        bool DeleteCandidates(int electionId, int candidateId);
        bool CandidateExists(int electionId, int candidateId);
        CandidatePositionDeleteViewModel CandidateDeleteView(int electionId, int candidateId);
        List<PositionListItem> GetPositions(int electionId, int candidateId);
        List<PositionListItem> GetSelectedPositions(List<int> selectedIds);
        List<Candidate> GetCandidates();
        ElectionIssueViewModel IssuesView(int electionId);
        ElectionIssueUpdateViewModel IssueUpdateView(int electionId);
        bool SaveIssue(ElectionIssue ei);
        bool DeleteIssue(int electionIssueId);
        bool IssueExists(int electionId, int issueId);
        ElectionIssueDeleteViewModel IssueDeleteView(int electionIssueId, int electionId);
        List<Issue> GetIssues();
    }
}
