﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.CandidatePositions;
using VotingApplication.Accessors.Candidates;
using VotingApplication.Accessors.ElectionIssues;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.Issues;
using VotingApplication.Accessors.Positions;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Elections
{
    public class ElectionManager : IElectionManager
    {
        #region "Dependency Injection"
        private readonly IElectionAccessor _electionAccessor;
        private readonly ICandidatePositionAccessor _candidatePositionAccessor;
        private readonly IElectionIssueAccessor _electionIssueAccessor;
        private readonly ICandidateAccessor _candidateAccessor;
        private readonly IIssueAccessor _issueAccessor;
        private readonly IPositionAccessor _positionAccessor;

        public ElectionManager
            (IElectionAccessor electionAccessor, 
            ICandidatePositionAccessor candidatePositionAccessor, 
            IElectionIssueAccessor electionIssueAccessor, 
            IIssueAccessor issueAccessor,
            IPositionAccessor positionAccessor,
            ICandidateAccessor candidateAccessor)
        {
            _electionAccessor = electionAccessor;
            _candidatePositionAccessor = candidatePositionAccessor;
            _electionIssueAccessor = electionIssueAccessor;
            _issueAccessor = issueAccessor;
            _positionAccessor = positionAccessor;
            _candidateAccessor = candidateAccessor;
        }
        #endregion

        #region "Elections"
        public ElectionViewModel DefaultView()
        {
            var view = new ElectionViewModel();

            try
            {
                view.Elections = _electionAccessor.Get();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Delete(int electionId)
        {
            bool successful;

            try
            {
                successful = _electionAccessor.Delete(electionId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Save(Election election)
        {
            bool successful;

            try
            {
                successful = _electionAccessor.Save(election);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Exists(int electionId, DateTime startDate, DateTime endDate)
        {
            bool exists = false;

            try
            {
                exists = _electionAccessor.Exists(electionId, startDate, endDate);
            }
            catch (Exception ex)
            {
                exists = false;
            }

            return exists;
        }

        public ElectionUpdateViewModel UpdateView(int electionId)
        {
            var view = new ElectionUpdateViewModel();

            try
            {
                if (electionId != 0)
                {
                    var election = _electionAccessor.Find(electionId);

                    view.ElectionId = election.ElectionId;
                    view.Name = election.Name;
                    view.StartDate = election.StartDate;
                    view.EndDate = election.EndDate;
                }
                else
                {
                    view.ElectionId = 0;
                    view.Name = "";
                    view.StartDate = DateTime.Today;
                    view.EndDate = DateTime.Today.AddMonths(1);
                }

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }
        #endregion

        #region "ElectionCandidates/CandidatePositions"
        public CandidatePositionViewModel CandidatesView(int electionId)
        {
            var view = new CandidatePositionViewModel();

            try
            {
                view.ElectionId = electionId;

                var lst = _candidatePositionAccessor.GetOrderedByCandidate(electionId);
                view.CandidatePositions = GetCandidatePositions(lst);
                
                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        private List<CandidatePositionTableItem> GetCandidatePositions(List<CandidatePosition> candidatePositions)
        {
            List<CandidatePositionTableItem> items = new List<CandidatePositionTableItem>();

            if (candidatePositions.Count > 0)
            {
                int prevCandidate = 0;
                int currCandidate = candidatePositions[0].CandidateId;

                // create and initialize first table item
                var tableItem = new CandidatePositionTableItem();
                tableItem.CandidateName = candidatePositions[0].CandidateName;
                tableItem.CandidateId = candidatePositions[0].CandidateId;
                tableItem.CandidatePositionId = candidatePositions[0].CandidatePositionId;
                tableItem.Positions.Add(new Position() { Name = candidatePositions[0].PositionName, PositionId = candidatePositions[0].PositionId });

                // loop through all other CandidatePositions
                for (int i = 1; i < candidatePositions.Count; i++)
                {
                    prevCandidate = currCandidate;
                    currCandidate = candidatePositions[i].CandidateId;

                    // current candidate same as previous candidate, add position to current table item
                    if (prevCandidate == currCandidate)
                        tableItem.Positions.Add(new Position() { Name = candidatePositions[i].PositionName, PositionId = candidatePositions[i].PositionId });
                    else
                    {
                        // current candidate is different than previous candidate, create and initialize new table item
                        items.Add(tableItem);

                        tableItem = new CandidatePositionTableItem();

                        tableItem.CandidateName = candidatePositions[i].CandidateName;
                        tableItem.CandidateId = candidatePositions[i].CandidateId;
                        tableItem.CandidatePositionId = candidatePositions[i].CandidatePositionId;

                        tableItem.Positions.Add(new Position() { Name = candidatePositions[i].PositionName, PositionId = candidatePositions[i].PositionId });
                    }
                }

                // add last table item
                items.Add(tableItem);
            }

            return items;
        }

        public CandidatePositionUpdateViewModel CandidateUpdateView(int electionId, int candidateId)
        {
            var view = new CandidatePositionUpdateViewModel();

            try
            {
                view.ElectionId = electionId;

                if (candidateId != 0)
                {
                    view.CandidateId = candidateId;
                    view.Update = true;
                }
                else
                {
                    view.CandidateId = 0;
                    view.Update = false;
                }

                view.Candidates = GetCandidates();
                view.Positions = GetPositions(electionId, candidateId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool SaveCandidate(CandidatePosition cp)
        {
            bool successful;

            try
            {
                successful = _candidatePositionAccessor.Save(cp);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool DeleteCandidates(int electionId, int candidateId)
        {
            bool successful;

            try
            {
                successful = _candidatePositionAccessor.Delete(electionId, candidateId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool CandidateExists(int electionId, int candidateId)
        {
            return _candidatePositionAccessor.Exists(electionId, candidateId);
        }

        public CandidatePositionDeleteViewModel CandidateDeleteView(int electionId, int candidateId)
        {
            var view = new CandidatePositionDeleteViewModel();

            try
            {
                view.ElectionId = electionId;
                view.CandidateId = candidateId;
                view.CandidateName = _candidateAccessor.Find(candidateId).FullName;

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public List<PositionListItem> GetPositions(int electionId, int candidateId)
        {
            var positionsSelected = _candidatePositionAccessor.Get(electionId, candidateId);
            List<int> selectedIds = new List<int>();
            foreach (var selectedPosition in positionsSelected)
                selectedIds.Add(selectedPosition.PositionId);

            return GetSelectedPositions(selectedIds);
        }

        public List<PositionListItem> GetSelectedPositions(List<int> selectedIds)
        {
            var positions = _positionAccessor.Get();
            List<PositionListItem> lstItems = new List<PositionListItem>();
            foreach (var position in positions)
            {
                if (selectedIds.Contains(position.PositionId))
                    lstItems.Add(new PositionListItem() { Position = position, Selected = true });
                else
                    lstItems.Add(new PositionListItem() { Position = position, Selected = false });
            }

            return lstItems;
        }

        public List<Candidate> GetCandidates()
        {
            return _candidateAccessor.Get();
        }
        #endregion

        #region "ElectionIssues"
        public ElectionIssueViewModel IssuesView(int electionId)
        {
            var view = new ElectionIssueViewModel();

            try
            {
                view.ElectionId = electionId;
                view.ElectionIssues = _electionIssueAccessor.Get(electionId);

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        /* Only for inserting election issues, updating will not be allowed */
        public ElectionIssueUpdateViewModel IssueUpdateView(int electionId)
        {
            var view = new ElectionIssueUpdateViewModel();

            try
            {
                view.ElectionId = electionId;
                view.IssueId = 0;

                view.Issues = GetIssues();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool SaveIssue(ElectionIssue ei)
        {
            bool successful;

            try
            {
                successful = _electionIssueAccessor.Save(ei);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool DeleteIssue(int electionIssueId)
        {
            bool successful;

            try
            {
                successful = _electionIssueAccessor.Delete(electionIssueId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool IssueExists(int electionId, int issueId)
        {
            bool exists;

            try
            {
                exists = _electionIssueAccessor.Exists(electionId, issueId);
            }
            catch (Exception ex)
            {
                exists = false;
            }

            return exists;
        }

        public ElectionIssueDeleteViewModel IssueDeleteView(int electionIssueId, int electionId)
        {
            var view = new ElectionIssueDeleteViewModel();

            try
            {
                view.ElectionId = electionId;
                view.ElectionIssueId = electionIssueId;
                view.IssueName = _electionIssueAccessor.Find(electionIssueId).IssueName;

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public List<Issue> GetIssues()
        {
            return _issueAccessor.Get();
        }
        #endregion
    }
}