﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.Positions;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Positions
{
    public class PositionManager : IPositionManager
    {
        private readonly IPositionAccessor _positionAccessor;

        public PositionManager(IPositionAccessor positionAccessor)
        {
            _positionAccessor = positionAccessor;
        }

        public PositionViewModel DefaultView()
        {
            var view = new PositionViewModel();

            try
            {
                view.Positions = _positionAccessor.Get();

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Delete(int positionId)
        {
            bool successful;

            try
            {
                successful = _positionAccessor.Delete(positionId);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public bool Save(Position position)
        {
            bool successful;

            try
            {
                successful = _positionAccessor.Save(position);
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        public PositionUpdateViewModel UpdateView(int positionId)
        {
            var view = new PositionUpdateViewModel();

            try
            {
                if (positionId != 0)
                {
                    var user = _positionAccessor.Find(positionId);

                    view.PositionId = user.PositionId;
                    view.Name = user.Name;
                }
                else
                {
                    view.PositionId = 0;
                    view.Name = "";
                }

                view.Error = false;
                view.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                view.Error = true;
                view.ErrorMessage = ex.Message;
            }

            return view;
        }

        public bool Exists(int positionId, string name)
        {
            bool exists;

            try
            {
                exists = _positionAccessor.Exists(positionId, name);
            }
            catch (Exception ex)
            {
                exists = false;
            }

            return exists;
        }
    }
}