﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Positions
{
    public interface IPositionManager
    {
        PositionViewModel DefaultView();
        PositionUpdateViewModel UpdateView(int positionId);
        bool Save(Position position);
        bool Delete(int positionId);
        bool Exists(int positionId, string name);
    }
}
