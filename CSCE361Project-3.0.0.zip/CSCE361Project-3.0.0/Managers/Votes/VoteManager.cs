﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.Accessors.CandidatePositions;
using VotingApplication.Accessors.ElectionIssues;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Votes
{
    public class VoteManager : IVoteManager
    {
        #region "Dependency Injection"
        private readonly IElectionAccessor _electionAccessor;
        private readonly ICandidatePositionAccessor _candidatePositionAccessor;
        private readonly IElectionIssueAccessor _electionIssueAccessor;
        private readonly IElectionVoteAccessor _electionVoteAccessor;
        private readonly IIssueVoteAccessor _issueVoteAccessor;

        public VoteManager (
            IElectionAccessor electionAccessor, 
            ICandidatePositionAccessor candidatePositionAccessor, 
            IElectionIssueAccessor electionIssueAccessor, 
            IElectionVoteAccessor electionVoteAccessor,
            IIssueVoteAccessor issueVoteAccessor)
        {
            _electionAccessor = electionAccessor;
            _candidatePositionAccessor = candidatePositionAccessor;
            _electionIssueAccessor = electionIssueAccessor;
            _electionVoteAccessor = electionVoteAccessor;
            _issueVoteAccessor = issueVoteAccessor;
        }
        #endregion

        public VoteViewModel DefaultView(int userId)
        {
            var model = new VoteViewModel();

            try
            {
                model.UserId = userId;
                var election = _electionAccessor.FindCurrent(DateTime.Now);

                if (election.ElectionId != 0)
                {
                    model.ElectionId = election.ElectionId;
                    model.ElectionName = election.Name;

                    if (Voted(userId, election.ElectionId))
                    {
                        model.UserVoted = true;
                        return model;
                    }

                    model.Positions = GetPositions(election.ElectionId);

                    model.Issues = GetIssues(election.ElectionId);
                }

                model.Error = false;
                model.ErrorMessage = "";
            }
            catch (Exception ex)
            {
                model.Error = true;
                model.ErrorMessage = ex.Message;
            }

            return model;
        }

        /* Manually Tested */
        public bool Save(List<ElectionVote> positionVotes, List<IssueVote> issueVotes)
        {
            bool successful = false;

            try
            {
                foreach (var ev in positionVotes)
                    successful = _electionVoteAccessor.Save(ev);

                foreach (var iv in issueVotes)
                    successful = _issueVoteAccessor.Save(iv);

                if (positionVotes.Count == 0 && issueVotes.Count == 0)
                    successful = true;
            }
            catch (Exception ex)
            {
                successful = false;
            }

            return successful;
        }

        private bool Voted(int userId, int electionId)
        {
            bool voted = false;

            try
            {
                voted = (_electionVoteAccessor.Get(userId, electionId).Count > 0) || (_issueVoteAccessor.Get(userId, electionId).Count > 0);
            } 
            catch (Exception ex)
            {
                voted = false;
            }

            return voted;
        }

        public List<ElectionPosition> GetPositions(int electionId)
        {
            var lst = new List<ElectionPosition>();

            var candidates = _candidatePositionAccessor.GetOrderedByPosition(electionId);
            if (candidates.Count > 0)
            {
                int prevPos = candidates[0].PositionId;
                int currPos;
                var item = new ElectionPosition();
                item.Id = prevPos;
                item.Name = candidates[0].PositionName;
                item.Candidates = new List<ElectionCandidate>();
                foreach (var candidate in candidates)
                {
                    currPos = candidate.PositionId;

                    if (prevPos != currPos)
                    {
                        lst.Add(item);
                        item = new ElectionPosition();
                        item.Id = currPos;
                        item.Name = candidate.PositionName;
                        item.Candidates = new List<ElectionCandidate>();
                    }

                    item.Candidates.Add(new ElectionCandidate() { CandidatePosition = candidate, Checked = false });

                    prevPos = currPos;
                }

                lst.Add(item);
            }

            return lst;
        }

        public List<ElectionIssueListItem> GetIssues(int electionId)
        {
            var lst = new List<ElectionIssueListItem>();

            var issues = _electionIssueAccessor.Get(electionId);
            foreach (var issue in issues)
                lst.Add(new ElectionIssueListItem() { Issue = issue, Checked = false });

            return lst;
        }
    }
}