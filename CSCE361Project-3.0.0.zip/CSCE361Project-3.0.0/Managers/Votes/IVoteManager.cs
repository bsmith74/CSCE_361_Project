﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;
using VotingApplication.Models;

namespace VotingApplication.Managers.Votes
{
    public interface IVoteManager
    {
        VoteViewModel DefaultView(int userId);
        /* Manually Tested */
        bool Save(List<ElectionVote> positionVotes, List<IssueVote> issueVotes);
        List<ElectionPosition> GetPositions(int electionId);
        List<ElectionIssueListItem> GetIssues(int electionId);
    }
}
