﻿# Custom Authentication
To create custom authentication for this application I used the following tutorial:
https://www.ifourtechnolab.com/blog/a-detailed-guide-on-custom-authentication-and-authorization-in-asp-net-mvc

## Database
For our application, we used a MySQL database rather than using Entity Framework, creating a few minor differences in our set up of custom authentication.

## Overview
The following custom authentication classes all inherit the authentication classes (or implement the interfaces) built-in to ASP.NET MVC. These classes
provide methods to authorize and authenticate users, and by inheriting them and overriding a few of their methods to suit our needs, we can develop custom
authentication for our web application. Our goal is to have three different roles: Developer, Administrator, and User, with decreasing privileges. Developers
have access to all developer privileges: they can interact with any database table via the admin tab pages. They can also use the site in the same way as any 
other user: to vote, view their votes, view results, etc. Administrators can access some developer privileges: they can interact with the elections,
candidates, and issues, and also can see if a particular user voted, but not how that user voted. They cannot interact with the users, roles, or specific 
candidate or issue votes. Users can use the site as intended: to vote, view their votes, view the results, view issue information, and view candidate
information. Creating custom authentication classes by inheriting the built-in authentication classes will give us the ability to have users log-in, at
which point they will be authenticated (or not authenticated), and their user id and roles will be saved to session storage for later user in page to page
authorization to determine a user's privileges.

### CustomMembership
CustomMembership class inherits the MembershipProvider class and overrides methods to validate the current user and get the current user. These methods
interact with our user accessor to perform these tasks.

### CustomMembershipUser
CustomMembershipUser class inherits the MembershipUser class; this class is just used to get important information about the current user. This class needs
to be referenced in the Web.config file in order to be used across the web application, specifically in the controller classes.

### CustomRole
CustomRole class inherits the RoleProvider class and overrides methods to both get and check the roles of the current user. These methods also interact with
our user accessor to find the current user and get that user's roles. This class also needs to be references in the Web.config file, also for use in the 
controller classes to check whether a user fits a certain role and should/shouldn't be allowed to access a page.

### CustomPrincipal
CustomPrincipal class implements the IPrincipal interface to get user fields from web requests. This class is directly accessible by the application's 
controllers via the 'User' keyword once we modify the Global.asax file to make it the default user property from HttpContext. In order to do this, the
CustomSerializeModel is created. This model simply mirrors the user fields used throughout the other custom authenication classes.

### LoginController
The LoginController class puts many of these elements together to allow users to login/logout or create an account. Once a user logs in, their user information
is saved in session storage and can be checked later for authorization, as mentioned above.

### Using Custom Authentication in Controllers
In controller classes, the [CustomAuthorize(Roles = "Role1, Role2, ... , RoleN")] tag is used to define which pages are accessible/not accessbile for the
specified roles. As mentioned as part of the CustomPrincipal class, the 'User' keyword can also be used in controller classes to access user information.

### Additional Features
The tutorial I followed also implemented an account activation feature through email, which could be added to this in the future, but would require changes to
the database and to several of the custom authenication classes described above.