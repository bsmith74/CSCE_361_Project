﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.Authentication
{
    public class CustomSerializeModel
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public List<string> RoleName { get; set; }

        public CustomSerializeModel()
        {
            UserId = 0;
            FirstName = "";
            LastName = "";
            RoleName = new List<string>();
        }
    }
}