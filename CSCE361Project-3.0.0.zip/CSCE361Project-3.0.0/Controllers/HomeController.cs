﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using VotingApplication.Authentication;
using VotingApplication.Managers.Candidates;
using VotingApplication.Managers.Issues;
using VotingApplication.Managers.MyVotes;
using VotingApplication.Managers.Results;
using VotingApplication.Managers.Votes;
using VotingApplication.Models;

namespace VotingApplication.Controllers
{
    public class HomeController : Controller
    {
        #region "Dependency Injection"
        private readonly IMyVoteManager _myVoteManager;
        private readonly IResultManager _resultManager;
        private readonly IVoteManager _voteManager;
        private readonly IIssueTabManager _issueTabManager;
        private readonly ICandidateTabManager _candidateTabManager;

        public HomeController(
            IMyVoteManager myVoteManager, 
            IResultManager resultManager, 
            IVoteManager voteManager, 
            IIssueTabManager issueTabManager,
            ICandidateTabManager candidateTabManager)
        {
            _myVoteManager = myVoteManager;
            _resultManager = resultManager;
            _voteManager = voteManager;
            _issueTabManager = issueTabManager;
            _candidateTabManager = candidateTabManager;
        }
        #endregion

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult Index()
        {
            return View();
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult Vote()
        {
            CustomMembershipUser user = (CustomMembershipUser)new CustomMembership().GetUser(User.Identity.Name, User.Identity.IsAuthenticated);

            return View(_voteManager.DefaultView(user.UserId));
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult MyVotes()
        {
            CustomMembershipUser user = (CustomMembershipUser) new CustomMembership().GetUser(User.Identity.Name, User.Identity.IsAuthenticated);

            return View(_myVoteManager.DefaultView(user.UserId, 0));
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult _MyVotesDetail(int p1, int p2)
        {
            return PartialView("~/Views/Home/_MyVotes.cshtml", _myVoteManager.DetailView(p1, p2));
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult Thankyou()
        {
            return View();
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult Results(int p1)
        {
            return View(_resultManager.DefaultView(p1));
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult Issues()
        {
            return View(_issueTabManager.DefaultView());
        }

        [CustomAuthorize(Roles = "Developer, Administrator, User")]
        public ActionResult Candidates()
        {
            return View(_candidateTabManager.DefaultView());
        }

        public ActionResult _ResultsDetail(int p1)
        {
            return PartialView("~/Views/Home/_Results.cshtml", _resultManager.DetailView(p1));
        }

        /* ONLY CALLED ON INITIAL PAGE LOAD TO CLEAR COOKIES - MAYBE SHOULD BE REMOVED IN FINAL RELEASE */
        [AllowAnonymous]
        public ActionResult PageLoad()
        {
            HttpCookie cookie = new HttpCookie("Cookie1", "");
            cookie.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(cookie);

            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }
    }
}