﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VotingApplication.DataContracts;
using VotingApplication.Managers.Positions;
using VotingApplication.Managers.Users;
using VotingApplication.Managers.Parties;
using VotingApplication.Managers.Issues;
using VotingApplication.Models;
using VotingApplication.Managers.Elections;
using VotingApplication.Managers.ElectionVotes;
using VotingApplication.Managers.IssueVotes;
using VotingApplication.Managers.Candidates;
using VotingApplication.Managers.Roles;
using VotingApplication.Authentication;
using VotingApplication.Managers.VoterVoted;

namespace VotingApplication.Controllers
{
    [CustomAuthorize(Roles = "Administrator, Developer")]
    public class AdminController : Controller
    {
        #region "Dependency Injection"
        private readonly IUserManager _userManager;
        private readonly IPositionManager _positionManager;
        private readonly IPartyManager _partyManager;
        private readonly IIssueManager _issueManager;
        private readonly IElectionManager _electionManager;
        private readonly IElectionVoteManager _electionVoteManager;
        private readonly IIssueVoteManager _issueVoteManager;
        private readonly ICandidateManager _candidateManager;
        private readonly IRoleManager _roleManager;
        private readonly IVoterVotedManager _voterVotedManager;

        public AdminController(
            IUserManager userManager, 
            IPositionManager positionManager, 
            IPartyManager partyManager, 
            IIssueManager issueManager, 
            IElectionManager electionManager, 
            IElectionVoteManager electionVoteManager, 
            IIssueVoteManager issueVoteManager, 
            ICandidateManager candidateManager,
            IRoleManager roleManager,
            IVoterVotedManager voterVotedManager)
        {
            _userManager = userManager;
            _positionManager = positionManager;
            _partyManager = partyManager;
            _issueManager = issueManager;
            _electionManager = electionManager;
            _electionVoteManager = electionVoteManager;
            _issueVoteManager = issueVoteManager;
            _candidateManager = candidateManager;
            _roleManager = roleManager;
            _voterVotedManager = voterVotedManager;
        }
        #endregion

        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }

        #region "Users"
        [CustomAuthorize(Roles = "Developer")]
        public ActionResult Users()
        {
            return View("~/Views/Admin/Users/Index.cshtml", _userManager.DefaultView());
        }

        [CustomAuthorize(Roles = "Developer")]
        public ActionResult UserUpdate(int p1)
        {
            return View("~/Views/Admin/Users/Update.cshtml", _userManager.UpdateView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        [HttpPost]
        public ActionResult UserUpdateRecord(UserUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                List<int> selectedRoles = new List<int>();
                foreach (var role in model.Roles)
                {
                    if (role.Selected)
                        selectedRoles.Add(role.Role.RoleId);
                }

                if (selectedRoles.Count == 0)
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "You must select one or more roles for the user!");

                    model.Roles = _userManager.GetSelectedRoles(selectedRoles);

                    return View("~/Views/Admin/Users/Update.cshtml", model);
                }

                if (_userManager.Exists(model.UserId, model.Username))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(string.Empty, "A user already exists with this username!");

                    model.Roles = _userManager.GetSelectedRoles(selectedRoles);

                    return View("~/Views/Admin/Users/Update.cshtml", model);
                }

                // delete all UserRoles records with the given userId
                bool successful = _userManager.DeleteRoles(model.UserId);

                if (successful && _userManager.Save(new User() { UserId = model.UserId, FirstName = model.FirstName, LastName = model.LastName, Username = model.Username, Password = model.Password }))
                {
                    // find saved userid by username
                    int id = _userManager.Find(model.Username);

                    if (id != 0)
                    {
                        // insert each selected role
                        foreach (var roleId in selectedRoles)
                            _userManager.SaveRole(id, roleId);
                    }
                    else
                    {
                        ModelState.Clear();
                        ModelState.AddModelError(string.Empty, "Something went wrong updating the user/user roles. Please try again.");

                        model.Roles = _userManager.GetSelectedRoles(selectedRoles);

                        return View("~/Views/Admin/Users/Update.cshtml", model);
                    }

                    return RedirectToAction("Users", "Admin");
                }
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    model.Roles = _userManager.GetSelectedRoles(selectedRoles);

                    return View("~/Views/Admin/Users/Update.cshtml", model);
                }
            }
            else
            {
                return View("~/Views/Admin/Users/Update.cshtml", model);
            }

        }

        [CustomAuthorize(Roles = "Developer")]
        public ActionResult UserDelete(int p1)
        {
            return View("~/Views/Admin/Users/Delete.cshtml", _userManager.UpdateView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        [HttpPost]
        public ActionResult UserDeleteRecord(UserUpdateViewModel model)
        {
            if (_userManager.Delete(model.UserId))
                return RedirectToAction("Users", "Admin");
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Users/Delete.cshtml", model);
            }
        }
        #endregion

        #region "Position"
        public ActionResult Positions()
        {
            return View("~/Views/Admin/Positions/Index.cshtml", _positionManager.DefaultView());
        }

        public ActionResult PositionUpdate(int p1)
        {
            return View("~/Views/Admin/Positions/Update.cshtml", _positionManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult PositionUpdateRecord(PositionUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (_positionManager.Exists(model.PositionId, model.Name))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "A position already exists with that name!");

                    return View("~/Views/Admin/Positions/Update.cshtml", model);
                }

                if (_positionManager.Save(new Position() { PositionId = model.PositionId, Name = model.Name }))
                    return RedirectToAction("Positions", "Admin");
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    return View("~/Views/Admin/Positions/Update.cshtml", model);
                }
            }
            else
            {
                return View("~/Views/Admin/Positions/Update.cshtml", model);
            }

        }

        public ActionResult PositionDelete(int p1)
        {
            return View("~/Views/Admin/Positions/Delete.cshtml", _positionManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult PositionDeleteRecord(PositionUpdateViewModel model)
        {
            if (_positionManager.Delete(model.PositionId))
                return RedirectToAction("Positions", "Admin");
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Positions/Delete.cshtml", model);
            }
        }
        #endregion

        #region "Party"
        public ActionResult Parties()
        {
            return View("~/Views/Admin/Parties/Index.cshtml", _partyManager.DefaultView());
        }

        public ActionResult PartyUpdate(int p1)
        {
            return View("~/Views/Admin/Parties/Update.cshtml", _partyManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult PartyUpdateRecord(PartyUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (_partyManager.Exists(model.PartyId, model.Name))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "A party already exists with that name!");

                    return View("~/Views/Admin/Parties/Update.cshtml", model);
                }

                if (_partyManager.Save(new Party() { PartyId = model.PartyId, Name = model.Name }))
                    return RedirectToAction("Parties", "Admin");
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    return View("~/Views/Admin/Parties/Update.cshtml", model);
                }
            }
            else
            {
                return View("~/Views/Admin/Parties/Update.cshtml", model);
            }

        }

        public ActionResult PartyDelete(int p1)
        {
            return View("~/Views/Admin/Parties/Delete.cshtml", _partyManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult PartyDeleteRecord(PartyUpdateViewModel model)
        {
            if (_partyManager.Delete(model.PartyId))
                return RedirectToAction("Parties", "Admin");
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Parties/Delete.cshtml", model);
            }
        }
        #endregion

        #region "Issue"
        public ActionResult Issues()
        {
            return View("~/Views/Admin/Issues/Index.cshtml", _issueManager.DefaultView());
        }

        public ActionResult IssueUpdate(int p1)
        {
            return View("~/Views/Admin/Issues/Update.cshtml", _issueManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult IssueUpdateRecord(IssueUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (_issueManager.Exists(model.IssueId, model.Name, model.Description))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "An issue with the same name and description already exists!");

                    return View("~/Views/Admin/Issues/Update.cshtml", model);
                }

                if (_issueManager.Save(new Issue() { IssueId = model.IssueId, Name = model.Name, Description = model.Description }))
                    return RedirectToAction("Issues", "Admin");
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    return View("~/Views/Admin/Issues/Update.cshtml", model);
                }
            }
            else
            {
                return View("~/Views/Admin/Issues/Update.cshtml", model);
            }

        }

        public ActionResult IssueDelete(int p1)
        {
            return View("~/Views/Admin/Issues/Delete.cshtml", _issueManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult IssueDeleteRecord(IssueUpdateViewModel model)
        {
            if (_issueManager.Delete(model.IssueId))
                return RedirectToAction("Issues", "Admin");
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Issues/Delete.cshtml", model);
            }
        }
        #endregion

        #region "Elections"
        public ActionResult Elections()
        {
            return View("~/Views/Admin/Elections/Index.cshtml", _electionManager.DefaultView());
        }

        public ActionResult ElectionUpdate(int p1)
        {
            return View("~/Views/Admin/Elections/Update.cshtml", _electionManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult ElectionUpdateRecord(ElectionUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (model.StartDate >= model.EndDate)
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "End Date must be later than Start Date!");

                    return View("~/Views/Admin/Elections/Update.cshtml", model);
                }

                if (_electionManager.Exists(model.ElectionId, model.StartDate, model.EndDate))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "An election already exists during the given time frame!");

                    return View("~/Views/Admin/Elections/Update.cshtml", model);
                }

                if (_electionManager.Save(new Election() { ElectionId = model.ElectionId, Name = model.Name, StartDate = model.StartDate, EndDate = model.EndDate }))
                    return RedirectToAction("Elections", "Admin");
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    return View("~/Views/Admin/Elections/Update.cshtml", model);
                }
            }
            else
            {
                return View("~/Views/Admin/Elections/Update.cshtml", model);
            }
        }

        public ActionResult ElectionDelete(int p1)
        {
            return View("~/Views/Admin/Elections/Delete.cshtml", _electionManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult ElectionDeleteRecord(ElectionUpdateViewModel model)
        {
            if (_electionManager.Delete(model.ElectionId))
                return RedirectToAction("Elections", "Admin");
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Elections/Delete.cshtml", model);
            }
        }

        public ActionResult ElectionCandidates(int p1)
        {
            return View("~/Views/Admin/Elections/ElectionCandidates/Index.cshtml", _electionManager.CandidatesView(p1));
        }

        public ActionResult ElectionCandidateUpdate(int p1, int p2)
        {
            return View("~/Views/Admin/Elections/ElectionCandidates/Update.cshtml", _electionManager.CandidateUpdateView(p1, p2));
        }

        [HttpPost]
        public ActionResult ElectionCandidateUpdateRecord(CandidatePositionUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                List<int> selectedPositions = new List<int>();
                foreach (var pos in model.Positions)
                {
                    if (pos.Selected)
                        selectedPositions.Add(pos.Position.PositionId);
                }

                if (!model.Update)
                {
                    if (_electionManager.CandidateExists(model.ElectionId, model.CandidateId))
                    {
                        ModelState.Clear();
                        ModelState.AddModelError(String.Empty, "The candidate is already running in this election!");

                        model.Candidates = _electionManager.GetCandidates();
                        model.Positions = _electionManager.GetSelectedPositions(selectedPositions);

                        return View("~/Views/Admin/Elections/ElectionCandidates/Update.cshtml", model);
                    }
                }

                if (selectedPositions.Count == 0)
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "You must select one or more positions that the candidate is running for!");

                    model.Candidates = _electionManager.GetCandidates();
                    model.Positions = _electionManager.GetSelectedPositions(selectedPositions);

                    return View("~/Views/Admin/Elections/ElectionCandidates/Update.cshtml", model);
                }

                // delete all CandidatePositions records with the designated electionId and candidateId
                bool successful = _electionManager.DeleteCandidates(model.ElectionId, model.CandidateId);

                if (successful)
                {
                    // add all selected positions to CandidatePositions
                    foreach (var id in selectedPositions)
                    {
                        _electionManager.SaveCandidate(new CandidatePosition()
                        {
                            CandidatePositionId = 0,
                            CandidateId = model.CandidateId,
                            PositionId = id,
                            ElectionId = model.ElectionId
                        });
                    }

                    return RedirectToAction("ElectionCandidates", "Admin", new { p1 = model.ElectionId });
                }
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    model.Candidates = _electionManager.GetCandidates();
                    model.Positions = _electionManager.GetSelectedPositions(selectedPositions);

                    return View("~/Views/Admin/Elections/ElectionCandidates/Update.cshtml", model);
                }
            }
            else
            {
                model.Candidates = _electionManager.GetCandidates();
                model.Positions = _electionManager.GetPositions(model.ElectionId, model.CandidateId);

                return View("~/Views/Admin/Elections/ElectionCandidates/Update.cshtml", model);
            }
        }

        public ActionResult ElectionCandidateDelete(int p1, int p2)
        {
            return View("~/Views/Admin/Elections/ElectionCandidates/Delete.cshtml", _electionManager.CandidateDeleteView(p1, p2));
        }

        [HttpPost]
        public ActionResult ElectionCandidateDeleteRecord(CandidatePositionDeleteViewModel model)
        {
            if (_electionManager.DeleteCandidates(model.ElectionId, model.CandidateId))
                return RedirectToAction("ElectionCandidates", "Admin", new { p1 = model.ElectionId });
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Elections/ElectionCandidates/Delete.cshtml", model);
            }
        }

        public ActionResult ElectionIssues(int p1)
        {
            return View("~/Views/Admin/Elections/ElectionIssues/Index.cshtml", _electionManager.IssuesView(p1));
        }

        public ActionResult ElectionIssueUpdate(int p1)
        {
            return View("~/Views/Admin/Elections/ElectionIssues/Update.cshtml", _electionManager.IssueUpdateView(p1));
        }

        [HttpPost]
        public ActionResult ElectionIssueUpdateRecord(ElectionIssueUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (_electionManager.IssueExists(model.ElectionId, model.IssueId))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "This issue already exists for the election!");

                    model.Issues = _electionManager.GetIssues();

                    return View("~/Views/Admin/Elections/ElectionIssues/Update.cshtml", model);
                }

                if (_electionManager.SaveIssue(new ElectionIssue() { ElectionId = model.ElectionId, IssueId = model.IssueId }))
                    return RedirectToAction("ElectionIssues", "Admin", new { p1 = model.ElectionId });
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    model.Issues = _electionManager.GetIssues();

                    return View("~/Views/Admin/Elections/ElectionIssues/Update.cshtml", model);
                }
            }
            else
            {
                model.Issues = _electionManager.GetIssues();

                return View("~/Views/Admin/Elections/ElectionIssues/Update.cshtml", model);
            }
        }

        public ActionResult ElectionIssueDelete(int p1, int p2)
        {
            return View("~/Views/Admin/Elections/ElectionIssues/Delete.cshtml", _electionManager.IssueDeleteView(p1, p2));
        }

        [HttpPost]
        public ActionResult ElectionIssueDeleteRecord(ElectionIssueDeleteViewModel model)
        {
            if (_electionManager.DeleteIssue(model.ElectionIssueId))
                return RedirectToAction("ElectionIssues", "Admin", new { p1 = model.ElectionId });
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Elections/ElectionIssues/Delete.cshtml", model);
            }
        }
        #endregion

        #region "ElectionVotes"
        [CustomAuthorize(Roles = "Developer")]
        public ActionResult ElectionVotes(int p1)
        {
            return View("~/Views/Admin/ElectionVotes/Index.cshtml", _electionVoteManager.DefaultView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        public ActionResult _ElectionVotesDetail(int p1)
        {
            return PartialView("~/Views/Admin/ElectionVotes/_Index.cshtml", _electionVoteManager.DetailView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        public ActionResult ElectionVoteDelete(int p1)
        {
            return View("~/Views/Admin/ElectionVotes/Delete.cshtml", _electionVoteManager.DeleteView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        [HttpPost]
        public ActionResult ElectionVoteDeleteRecord(ElectionVoteDeleteViewModel model)
        {
            if (_electionVoteManager.Delete(model.ElectionVoteId))
                return RedirectToAction("ElectionVotes", "Admin", new { p1 = model.ElectionId });
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/ElectionVotes/Delete.cshtml", model);
            }
        }
        #endregion

        #region "IssueVotes"
        [CustomAuthorize(Roles = "Developer")]
        public ActionResult IssueVotes(int p1)
        {
            return View("~/Views/Admin/IssueVotes/Index.cshtml", _issueVoteManager.DefaultView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        public ActionResult _IssueVotesDetail(int p1)
        {
            return PartialView("~/Views/Admin/IssueVotes/_Index.cshtml", _issueVoteManager.DetailView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        public ActionResult IssueVoteDelete(int p1)
        {
            return View("~/Views/Admin/IssueVotes/Delete.cshtml", _issueVoteManager.DeleteView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        [HttpPost]
        public ActionResult IssueVoteDeleteRecord(IssueVoteDeleteViewModel model)
        {
            if (_issueVoteManager.Delete(model.IssueVoteId))
                return RedirectToAction("IssueVotes", "Admin", new { p1 = model.ElectionId });
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/IssueVotes/Delete.cshtml", model);
            }
        }
        #endregion

        #region "Candidates"
        public ActionResult Candidates()
        {
            return View("~/Views/Admin/Candidates/Index.cshtml", _candidateManager.DefaultView());
        }

        public ActionResult CandidateUpdate(int p1)
        {
            return View("~/Views/Admin/Candidates/Update.cshtml", _candidateManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult CandidateUpdateRecord(CandidateUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (_candidateManager.Exists(model.CandidateId, model.FirstName, model.LastName))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "A candidate with that first and last name already exists!");

                    model.Parties = _candidateManager.GetParties();

                    return View("~/Views/Admin/Candidates/Update.cshtml", model);
                }

                if (_candidateManager.Save(new Candidate() { CandidateId = model.CandidateId, FirstName = model.FirstName, LastName = model.LastName, Description = model.Description, PartyId = model.PartyId }))
                    return RedirectToAction("Candidates", "Admin");
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    model.Parties = _candidateManager.GetParties();

                    return View("~/Views/Admin/Candidates/Update.cshtml", model);
                }
            }
            else
            {
                model.Parties = _candidateManager.GetParties();

                return View("~/Views/Admin/Candidates/Update.cshtml", model);
            }

        }

        public ActionResult CandidateDelete(int p1)
        {
            return View("~/Views/Admin/Candidates/Delete.cshtml", _candidateManager.UpdateView(p1));
        }

        [HttpPost]
        public ActionResult CandidateDeleteRecord(CandidateUpdateViewModel model)
        {
            if (_candidateManager.Delete(model.CandidateId))
                return RedirectToAction("Candidates", "Admin");
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Candidates/Delete.cshtml", model);
            }
        }
        #endregion

        #region "Roles"
        [CustomAuthorize(Roles = "Developer")]
        public ActionResult Roles()
        {
            return View("~/Views/Admin/Roles/Index.cshtml", _roleManager.DefaultView());
        }

        [CustomAuthorize(Roles = "Developer")]
        public ActionResult RoleUpdate(int p1)
        {
            return View("~/Views/Admin/Roles/Update.cshtml", _roleManager.UpdateView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        [HttpPost]
        public ActionResult RoleUpdateRecord(RoleUpdateViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (_roleManager.Save(new Role() { RoleId = model.RoleId, Name = model.Name }))
                    return RedirectToAction("Roles", "Admin");
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                    return View("~/Views/Admin/Roles/Update.cshtml", model);
                }
            }
            else
            {
                return View("~/Views/Admin/Roles/Update.cshtml", model);
            }

        }

        [CustomAuthorize(Roles = "Developer")]
        public ActionResult RoleDelete(int p1)
        {
            return View("~/Views/Admin/Roles/Delete.cshtml", _roleManager.UpdateView(p1));
        }

        [CustomAuthorize(Roles = "Developer")]
        [HttpPost]
        public ActionResult RoleDeleteRecord(RoleUpdateViewModel model)
        {
            if (_roleManager.Delete(model.RoleId))
                return RedirectToAction("Roles", "Admin");
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Something went wrong. Please try again.");

                return View("~/Views/Admin/Roles/Delete.cshtml", model);
            }
        }
        #endregion

        #region "VoterVoted"
        public ActionResult VoterVoted(int p1)
        {
            return View("~/Views/Admin/VoterVoted/Index.cshtml", _voterVotedManager.DefaultView(p1));
        }

        public ActionResult _VoterVotedDetail(int p1)
        {
            return PartialView("~/Views/Admin/VoterVoted/_Index.cshtml", _voterVotedManager.DetailView(p1));
        }
        #endregion
    }
}