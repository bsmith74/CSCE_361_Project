﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.Authentication;
using VotingApplication.Managers.Votes;
using VotingApplication.Models;

namespace VotingApplication.Controllers
{
    [CustomAuthorize(Roles = "Developer, Administrator, User")]
    public class VoteController : Controller
    {
        private readonly IVoteManager _voteManager;

        public VoteController(IVoteManager voteManager)
        {
            _voteManager = voteManager;
        }

        [HttpPost]
        public ActionResult Vote(VoteViewModel model)
        {
            if (ModelState.IsValid)
            {
                var posLst = new List<DataContracts.ElectionVote>();
                var issLst = new List<DataContracts.IssueVote>();

                foreach (var position in model.Positions)
                {
                    foreach (var candidate in position.Candidates)
                    {
                        if (candidate.Checked)
                            posLst.Add(new DataContracts.ElectionVote()
                            {
                                CandidateId = candidate.CandidatePosition.CandidateId,
                                PositionId = candidate.CandidatePosition.PositionId,
                                ElectionId = model.ElectionId,
                                UserId = model.UserId
                            });
                    }
                }

                foreach (var issue in model.Issues)
                {
                    if (issue.Checked)
                        issLst.Add(new DataContracts.IssueVote()
                        {
                            IssueId = issue.Issue.IssueId,
                            ElectionId = model.ElectionId,
                            UserId = model.UserId,
                            Vote = 1
                        });
                    else
                        issLst.Add(new DataContracts.IssueVote()
                        {
                            IssueId = issue.Issue.IssueId,
                            ElectionId = model.ElectionId,
                            UserId = model.UserId,
                            Vote = 0
                        });
                }

                if (_voteManager.Save(posLst, issLst))
                    return RedirectToAction("Thankyou", "Home", null);
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Something went wrong submitting your votes. Please re-enter them and try again. Sorry for the incovenience.");

                    model.Positions = _voteManager.GetPositions(model.ElectionId);
                    model.Issues = _voteManager.GetIssues(model.ElectionId);

                    return View("~/Views/Home/Vote.cshtml", model);
                }
            }
            else
            {
                return View("~/Views/Home/Vote.cshtml", model);
            }
        }
    }
}