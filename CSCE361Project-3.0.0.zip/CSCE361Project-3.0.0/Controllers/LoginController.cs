﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using VotingApplication.Authentication;
using VotingApplication.Managers.Users;
using VotingApplication.Models;

namespace VotingApplication.Controllers
{
    [AllowAnonymous]
    public class LoginController : Controller
    {
        private readonly IUserManager _userManager;

        public LoginController(IUserManager userManager)
        {
            _userManager = userManager;
        }

        [HttpGet]
        public ActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
                return LogOut();

            return View("~/Views/Home/Login.cshtml");
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (Membership.ValidateUser(model.Username, model.Password))
                {
                    var user = (CustomMembershipUser)Membership.GetUser(model.Username, false);

                    if (user != null)
                    {
                        CustomSerializeModel userModel = new CustomSerializeModel()
                        {
                            UserId = user.UserId,
                            FirstName = user.FirstName,
                            LastName = user.LastName,
                            RoleName = user.Roles.Select(r => r.Name).ToList()
                        };

                        string userData = JsonConvert.SerializeObject(userModel);
                        FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(1, model.Username, DateTime.Now, DateTime.Now.AddMinutes(30), false, userData);

                        string enTicket = FormsAuthentication.Encrypt(authTicket);
                        HttpCookie faCookie = new HttpCookie("Cookie1", enTicket);
                        Response.Cookies.Add(faCookie);
                    }

                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Invalid Username or Password. Please try again or create an account below.");

                    return View("~/Views/Home/Login.cshtml", model);
                }
            }
            else
            {
                ModelState.Clear();
                ModelState.AddModelError(String.Empty, "Invalid Username or Password. Please try again or create an account below.");

                return View("~/Views/Home/Login.cshtml", model);
            }
        }

        [HttpGet]
        public ActionResult CreateAccount()
        {
            return View(new CreateAccountViewModel());
        }

        [HttpPost]
        public ActionResult CreateAccount(CreateAccountViewModel model)
        {
            bool statusRegistration = false;
            string messageRegistration = "";

            if (ModelState.IsValid)
            {
                if (String.IsNullOrEmpty(model.FirstName))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "First Name is a required field!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (model.FirstName.Length > 20)
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Sorry! First Name cannot be more than 20 characters!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (String.IsNullOrEmpty(model.LastName))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Last Name is a required field!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (model.LastName.Length > 20)
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Sorry! Last Name cannot be more than 20 characters!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (String.IsNullOrEmpty(model.Username))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Username is a required field!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (model.Username.Length < 4 || model.Username.Length > 20)
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Your username must be between 4 and 20 characters!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (String.IsNullOrEmpty(model.Password))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Password is a required field!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (model.Password.Length < 8 || model.Password.Length > 20)
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Your password must be between 8 and 20 characters!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (String.IsNullOrEmpty(model.ConfirmPassword))
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Confirm Password is a required field!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                if (model.Password != model.ConfirmPassword)
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "Your passwords do not match!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                // GetUserNameByEmail(string email) really should be called GetUserIdByUsername(string username)
                string userId = Membership.GetUserNameByEmail(model.Username);
                if (userId != "0")
                {
                    ModelState.Clear();
                    ModelState.AddModelError(String.Empty, "A user with this username already exists!");

                    return View("~/Views/Login/CreateAccount.cshtml", model);
                }

                // Save User Data
                _userManager.Save(new DataContracts.User()
                {
                    UserId = 0,
                    Username = model.Username,
                    Password = model.Password,
                    FirstName = model.FirstName,
                    LastName = model.LastName
                });

                // Give the new User 'User' priviledges
                int newUserId = _userManager.Find(model.Username);
                _userManager.SaveRole(newUserId, 1);

                messageRegistration = "Your account has been created successfully.";
                statusRegistration = true;
            }
            else
            {
                messageRegistration = "Something went wrong!";
            }

            ViewBag.Message = messageRegistration;
            ViewBag.Status = statusRegistration;

            return View("~/Views/Home/Login.cshtml");
        }

        public ActionResult LogOut()
        {
            HttpCookie cookie = new HttpCookie("Cookie1", "");
            cookie.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(cookie);

            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Home");
        }

        public ActionResult AccessDenied()
        {
            return View();
        }
    }
}