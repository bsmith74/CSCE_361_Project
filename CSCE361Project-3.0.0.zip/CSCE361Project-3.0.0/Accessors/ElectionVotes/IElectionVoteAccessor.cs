﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.ElectionVotes
{
    public interface IElectionVoteAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<ElectionVote> Get();
        List<ElectionVote> Get(int electionId);
        List<ElectionVote> Get(int userId, int electionId);
        ElectionVote Find(int electionVoteId);
        bool Delete(int electionVoteId);
        bool Save(ElectionVote electionVote);
    }
}
