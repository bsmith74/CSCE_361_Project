﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.ElectionVotes
{
    public class ElectionVoteAccessor : IElectionVoteAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public ElectionVoteAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<ElectionVote> Collection(string where, string orderby)
        {
            var lst = new List<ElectionVote>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"SELECT electionVoteId, EV.positionId, P.name AS positionName, EV.candidateId, 
                                        C.firstName AS candidateFirstName, C.lastName AS candidateLastName, 
                                        EV.userId, U.firstName AS userFirstName, U.lastName AS userLastName, electionId
                                    FROM ElectionVotes EV 
                                        left outer join Positions P on P.positionId = EV.positionId
                                        left outer join Candidates C on C.candidateId = EV.candidateId
                                        left outer join Users U on U.userId = EV.userId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var electionVote = new ElectionVote();

                                int.TryParse(reader["electionVoteId"].ToString(), out id);
                                electionVote.ElectionVoteId = id;

                                int.TryParse(reader["positionId"].ToString(), out id);
                                electionVote.PositionId = id;

                                electionVote.PositionName = reader["positionName"].ToString();

                                int.TryParse(reader["candidateId"].ToString(), out id);
                                electionVote.CandidateId = id;

                                electionVote.CandidateName = reader["candidateFirstName"].ToString() + " " + reader["candidateLastName"].ToString();

                                int.TryParse(reader["userId"].ToString(), out id);
                                electionVote.UserId = id;

                                electionVote.UserName = reader["userFirstName"].ToString() + " " + reader["userLastName"].ToString();

                                int.TryParse(reader["electionId"].ToString(), out id);
                                electionVote.ElectionId = id;

                                lst.Add(electionVote);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public List<ElectionVote> Get()
        {
            return Collection("", "");
        }

        public List<ElectionVote> Get(int electionId)
        {
            return Collection("electionId = " + electionId.ToString(), "");
        }

        public List<ElectionVote> Get(int userId, int electionId)
        {
            return Collection("EV.userId = " + userId.ToString() + " AND electionId = " + electionId.ToString(), "");
        }

        public ElectionVote Find(int electionVoteId)
        {
            var ev = new ElectionVote();

            try
            {
                var lst = Collection("electionVoteId = " + electionVoteId.ToString(), "");

                if (lst.Count() == 1)
                {
                    ev = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find an election vote with electionVoteId = " + electionVoteId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return ev;
        }

        public bool Delete(int electionVoteId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM ElectionVotes WHERE electionVoteId = @electionVoteId";

                        command.Parameters.AddWithValue("@electionVoteId", electionVoteId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Insert(ElectionVote ev)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = @"INSERT INTO ElectionVotes (positionId, candidateId, userId, electionId) 
                                                                   VALUES (@positionId, @candidateId, @userId, @electionId)";

                        command.Parameters.AddWithValue("@positionId", ev.PositionId);
                        command.Parameters.AddWithValue("@candidateId", ev.CandidateId);
                        command.Parameters.AddWithValue("@userId", ev.UserId);
                        command.Parameters.AddWithValue("@electionId", ev.ElectionId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(ElectionVote ev)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = @"UPDATE ElectionVotes SET positionId = @positionId, candidateId = @candidateId, userId = @userId
                                                    electionId = @electionId WHERE electionVoteId = @electionVoteId";

                        command.Parameters.AddWithValue("@positionId", ev.PositionId);
                        command.Parameters.AddWithValue("@candidateId", ev.CandidateId);
                        command.Parameters.AddWithValue("@userId", ev.UserId);
                        command.Parameters.AddWithValue("@electionId", ev.ElectionId);
                        command.Parameters.AddWithValue("@electionVoteId", ev.ElectionVoteId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(ElectionVote electionVote)
        {
            if (electionVote.ElectionVoteId == 0)
                return Insert(electionVote);
            else
                return Update(electionVote);
        }
    }
}