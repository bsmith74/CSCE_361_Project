﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;


namespace VotingApplication.Accessors.Issues
{
    public interface IIssueAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<Issue> Get();
        Issue Find(int issueId);
        bool Exists(int issueId, string name, string description);
        bool Delete(int issueId);
        bool Save(Issue issue);
    }
}
