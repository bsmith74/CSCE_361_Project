﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Issues
{
    public class IssueAccessor : IIssueAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public IssueAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<Issue> Collection(string where, string orderby)
        {
            var lst = new List<Issue>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append("SELECT issueId, name, description FROM Issues");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var issue = new Issue();

                                int.TryParse(reader["issueId"].ToString(), out id);
                                issue.IssueId = id;

                                issue.Name = reader["name"].ToString();

                                issue.Description = reader["description"].ToString();

                                lst.Add(issue);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public bool Delete(int issueId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM Issues WHERE issueId = @issueId";

                        command.Parameters.AddWithValue("@issueId", issueId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public Issue Find(int issueId)
        {
            var issue = new Issue();

            try
            {
                var lst = Collection("issueId = " + issueId.ToString(), "");

                if (lst.Count() == 1)
                {
                    issue = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find issue with issueId = " + issueId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return issue;
        }

        public bool Exists(int issueId, string name, string description)
        {
            bool exists = false;

            try
            {
                name.Replace("'", "\'");
                description.Replace("'", "\'");
                var lst = Collection("issueId <> " + issueId + " AND name = '" + name + "' AND description = '" + description + "'", "");

                if (lst.Count > 0)
                    exists = true;
                else
                    exists = false;

                Successful = true;
                Message = "";
            }
            catch (Exception ex)
            {
                Successful = false;
                Message = ex.Message;
            }

            return exists;
        }

        public List<Issue> Get()
        {
            return Collection("", "");
        }

        private bool Insert(Issue issue)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Issues (name, description) VALUES (@name, @description)";

                        command.Parameters.AddWithValue("@name", issue.Name);
                        command.Parameters.AddWithValue("@description", issue.Description);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(Issue issue)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE Issues SET name = @name, description = @description WHERE issueId = @issueId";

                        command.Parameters.AddWithValue("@name", issue.Name);
                        command.Parameters.AddWithValue("@description", issue.Description);

                        command.Parameters.AddWithValue("@issueId", issue.IssueId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(Issue issue)
        {
            if (issue.IssueId == 0)
                return Insert(issue);
            else
                return Update(issue);
        }
    }
}