﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.ElectionIssues
{
    public interface IElectionIssueAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<ElectionIssue> Get();
        List<ElectionIssue> Get(int electionId);
        ElectionIssue Find(int electionIssueId);
        bool Exists(int electionId, int issueId);
        bool Delete(int electionIssueId);
        bool Save(ElectionIssue electionIssue);
    }
}
