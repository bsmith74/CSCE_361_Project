﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.ElectionIssues
{
    public class ElectionIssueAccessor : IElectionIssueAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public ElectionIssueAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<ElectionIssue> Collection(string where, string orderby)
        {
            var lst = new List<ElectionIssue>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"SELECT electionIssueId, electionId, EI.issueId, name FROM ElectionIssues EI
                                       LEFT OUTER JOIN Issues I ON I.issueId = EI.issueId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var ei = new ElectionIssue();

                                int.TryParse(reader["electionIssueId"].ToString(), out id);
                                ei.ElectionIssueId = id;

                                int.TryParse(reader["electionId"].ToString(), out id);
                                ei.ElectionId = id;

                                int.TryParse(reader["issueId"].ToString(), out id);
                                ei.IssueId = id;

                                ei.IssueName = reader["name"].ToString();

                                lst.Add(ei);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Successful = false;
                Message = ex.Message;
            }

            return lst;
        }

        public bool Delete(int electionIssueId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM ElectionIssues WHERE electionIssueId = @electionIssueId";

                        command.Parameters.AddWithValue("@electionIssueId", electionIssueId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public ElectionIssue Find(int electionIssueId)
        {
            var ei = new ElectionIssue();

            try
            {
                var lst = Collection("electionIssueId = " + electionIssueId.ToString(), "");

                if (lst.Count() == 1)
                {
                    ei = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find election issue with electionIssueId = " + electionIssueId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return ei;
        }

        public bool Exists(int electionId, int issueId)
        {
            bool exists = false;

            try
            {
                var lst = Collection("electionId = " + electionId.ToString() + " AND EI.issueId = " + issueId.ToString(), "");

                if (lst.Count() > 0)
                    exists = true;
                else
                    exists = false;

                Message = "";
                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return exists;
        }

        public List<ElectionIssue> Get()
        {
            return Collection("", "");
        }

        public List<ElectionIssue> Get(int electionId)
        {
            return Collection("electionId = " + electionId.ToString(), "");
        }

        private bool Insert(ElectionIssue ei)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO ElectionIssues (electionId, issueId) VALUES (@electionId, @issueId)";

                        command.Parameters.AddWithValue("@electionId", ei.ElectionId);
                        command.Parameters.AddWithValue("@issueId", ei.IssueId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(ElectionIssue ei)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE ElectionIssues SET electionId = @electionId, issueId = @issueId WHERE electionIssueId = @electionIssueId";

                        command.Parameters.AddWithValue("@electionId", ei.ElectionId);
                        command.Parameters.AddWithValue("@issueId", ei.IssueId);
                        command.Parameters.AddWithValue("@electionIssueId", ei.ElectionIssueId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(ElectionIssue electionIssue)
        {
            if (electionIssue.ElectionIssueId == 0)
                return Insert(electionIssue);
            else
                return Update(electionIssue);
        }
    }
}