﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.CandidatePositions
{
    public interface ICandidatePositionAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<CandidatePosition> Get();
        List<CandidatePosition> GetOrderedByCandidate(int electionId);
        List<CandidatePosition> GetOrderedByPosition(int electionId);
        List<CandidatePosition> Get(int electionId, int candidateId);
        bool Exists(int electionId, int candidateId);
        bool Delete(int candidatePositionId);
        bool Delete(int electionId, int candidateId);
        bool Save(CandidatePosition candidatePosition);
    }
}
