﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.CandidatePositions
{
    public class CandidatePositionAccessor : ICandidatePositionAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public CandidatePositionAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<CandidatePosition> Collection(string where, string orderby)
        {
            var lst = new List<CandidatePosition>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"SELECT candidatePositionId, CP.positionId, P.name, electionId, CP.candidateId, C.firstName, C.lastName
                                    FROM CandidatePositions CP
                                    LEFT OUTER JOIN Positions P ON P.positionId = CP.positionId
                                    LEFT OUTER JOIN Candidates C ON C.candidateId = CP.candidateId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var cp = new CandidatePosition();

                                int.TryParse(reader["candidatePositionId"].ToString(), out id);
                                cp.CandidatePositionId = id;

                                int.TryParse(reader["positionId"].ToString(), out id);
                                cp.PositionId = id;

                                int.TryParse(reader["electionId"].ToString(), out id);
                                cp.ElectionId = id;

                                int.TryParse(reader["candidateId"].ToString(), out id);
                                cp.CandidateId = id;

                                cp.PositionName = reader["name"].ToString();

                                cp.CandidateName = reader["firstName"].ToString() + " " + reader["lastName"].ToString();

                                lst.Add(cp);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public bool Delete(int candidatePositionId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM CandidatePositions WHERE candidatePositionId = @candidatePositionId";

                        command.Parameters.AddWithValue("@candidatePositionId", candidatePositionId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Delete(int electionId, int candidateId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM CandidatePositions WHERE electionId = @electionId AND candidateId = @candidateId";

                        command.Parameters.AddWithValue("@electionId", electionId);
                        command.Parameters.AddWithValue("@candidateId", candidateId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        Message = "";
                        Successful = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public List<CandidatePosition> Get()
        {
            return Collection("", "");
        }

        public List<CandidatePosition> GetOrderedByCandidate(int electionId)
        {
            return Collection("electionId = " + electionId.ToString(), "CP.candidateId");
        }

        public List<CandidatePosition> GetOrderedByPosition(int electionId)
        {
            return Collection("electionId = " + electionId.ToString(), "CP.positionId");
        }

        public List<CandidatePosition> Get(int electionId, int candidateId)
        {
            return Collection("electionId = " + electionId.ToString() + " AND CP.candidateId = " + candidateId.ToString(), "");
        }

        private bool Insert(CandidatePosition cp)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO CandidatePositions (positionId, electionId, candidateId) VALUES (@positionId, @electionId, @candidateId)";

                        command.Parameters.AddWithValue("@positionId", cp.PositionId);
                        command.Parameters.AddWithValue("@electionId", cp.ElectionId);
                        command.Parameters.AddWithValue("@candidateId", cp.CandidateId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(CandidatePosition cp)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = @"UPDATE CandidatePositions SET positionId = @positionId, candidateId = @candidateId, electionId = @electionId 
                                                WHERE candidatePositionId = @candidatePositionId";

                        command.Parameters.AddWithValue("@positionId", cp.PositionId);
                        command.Parameters.AddWithValue("@candidateId", cp.CandidateId);
                        command.Parameters.AddWithValue("@electionId", cp.ElectionId);
                        command.Parameters.AddWithValue("@candidatePositionId", cp.CandidatePositionId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(CandidatePosition candidatePosition)
        {
            if (candidatePosition.CandidatePositionId == 0)
                return Insert(candidatePosition);
            else
                return Update(candidatePosition);
        }

        public bool Exists(int electionId, int candidateId)
        {
            bool exists = false;

            try
            {
                var lst = Collection("electionId = " + electionId.ToString() + " AND CP.candidateId = " + candidateId.ToString(), "");

                if (lst.Count() > 0)
                    exists = true;
                else
                    exists = false;

                Message = "";
                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return exists;
        }
    }
}