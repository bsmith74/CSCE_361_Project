﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Elections
{
    public interface IElectionAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<Election> Get();
        List<Election> GetFinished();
        Election FindCurrent(DateTime dt);
        Election Find(int electionId);
        bool Exists(int electionId, DateTime startDate, DateTime endDate);
        bool Delete(int electionId);
        bool Save(Election election);
        bool Save(int electionId, DateTime startDate, DateTime endDate, string name);
    }
}
