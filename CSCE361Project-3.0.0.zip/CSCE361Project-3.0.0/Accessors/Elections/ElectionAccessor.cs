﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Elections
{
    public class ElectionAccessor : IElectionAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public ElectionAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<Election> Collection(string where, string orderby)
        {
            var lst = new List<Election>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append("SELECT electionId, startDate, endDate, name FROM Elections");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var election = new Election();

                                int.TryParse(reader["electionId"].ToString(), out id);
                                election.ElectionId = id;

                                DateTime.TryParse(reader["startDate"].ToString(), out DateTime startDate);
                                election.StartDate = startDate;

                                DateTime.TryParse(reader["endDate"].ToString(), out DateTime endDate);
                                election.EndDate = endDate;

                                election.Name = reader["name"].ToString();

                                lst.Add(election);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public bool Delete(int electionId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM Elections WHERE electionId = @electionId";

                        command.Parameters.AddWithValue("@electionId", electionId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public Election Find(int electionId)
        {
            var election = new Election();

            try
            {
                var lst = Collection("electionId = " + electionId.ToString(), "");

                if (lst.Count() == 1)
                {
                    election = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find election with electionId = " + electionId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return election;
        }

        public Election FindCurrent(DateTime dt)
        {
            var election = new Election();

            try
            {
                // sql dates in form: 'YYYY-MM-DD'
                string date = dt.Year.ToString() + "-" + dt.Month.ToString() + "-" + dt.Day.ToString();
                var lst = Collection("startDate <= '" + date + "' AND endDate >= '" + date + "'", "");

                if (lst.Count() == 1)
                {
                    election = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find a current election for this date: '" + dt.ToShortDateString() + "'.";
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return election;
        }

        public List<Election> Get()
        {
            return Collection("", "");
        }

        public List<Election> GetFinished()
        {
            DateTime dt = DateTime.Now;
            string date = dt.Year.ToString() + "-" + dt.Month.ToString() + "-" + dt.Day.ToString();
            return Collection("endDate < '" + date + "'", "");
        }

        public bool Exists(int electionId, DateTime startDate, DateTime endDate)
        {
            bool exists = false;

            try
            {
                // sql dates in form: 'YYYY-MM-DD'
                string date1 = startDate.Year.ToString() + "-" + startDate.Month.ToString() + "-" + startDate.Day.ToString();
                string date2 = endDate.Year.ToString() + "-" + endDate.Month.ToString() + "-" + endDate.Day.ToString();

                // check that the startDate does not overlap with another Election
                var lst1 = Collection("startDate <= '" + date1 + "' AND endDate >= '" + date1 + "' AND electionId <> " + electionId.ToString(), "");
                // check that the endDate does not overlap with another Election
                var lst2 = Collection("startDate >= '" + date2 + "' AND endDate <= '" + date2 + "' AND electionId <> " + electionId.ToString(), "");

                if (lst1.Count() > 0 || lst2.Count() > 0)
                    exists = true;
                else
                    exists = false;

                Message = "";
                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return exists;
        }

        private bool Insert(Election election)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Elections (startDate, endDate, name) VALUES (@startDate, @endDate, @name)";

                        command.Parameters.AddWithValue("@startDate", election.StartDate);
                        command.Parameters.AddWithValue("@endDate", election.EndDate);
                        command.Parameters.AddWithValue("@name", election.Name);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(Election election)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE Elections SET startDate = @startDate, endDate = @endDate, name = @name WHERE electionId = @electionId";

                        command.Parameters.AddWithValue("@startDate", election.StartDate);
                        command.Parameters.AddWithValue("@endDate", election.EndDate);
                        command.Parameters.AddWithValue("@name", election.Name);
                        command.Parameters.AddWithValue("@electionId", election.ElectionId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(Election election)
        {
            if (election.ElectionId == 0)
                return Insert(election);
            else
                return Update(election);
        }

        public bool Save(int electionId, DateTime startDate, DateTime endDate, string name)
        {
            return Save(new Election() { ElectionId = electionId, StartDate = startDate, EndDate = endDate, Name = name });
        }
    }
}