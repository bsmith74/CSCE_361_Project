﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Candidates
{
    public interface ICandidateAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<Candidate> Get();
        Candidate Find(int candidateId);
        bool Exists(int candidateId, string first, string last);
        bool Delete(int candidateId);
        bool Save(Candidate candidate);
    }
}
