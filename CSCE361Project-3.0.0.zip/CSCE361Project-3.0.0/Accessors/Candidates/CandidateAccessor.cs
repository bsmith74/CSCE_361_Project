﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Candidates
{
    public class CandidateAccessor : ICandidateAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }
        
        public CandidateAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<Candidate> Collection(string where, string orderby)
        {
            var lst = new List<Candidate>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"Select candidateId, firstName, lastName, description, C.partyId, P.name 
                                    FROM Candidates C
                                        left outer join Party P on P.partyId = C.partyId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var candidate = new Candidate();

                                int.TryParse(reader["candidateId"].ToString(), out id);
                                candidate.CandidateId = id;

                                candidate.FirstName = reader["firstName"].ToString();

                                candidate.LastName = reader["lastName"].ToString();

                                candidate.FullName = reader["firstName"].ToString() + " " + reader["lastname"].ToString();

                                candidate.Description = reader["description"].ToString();
                                
                                int.TryParse(reader["partyId"].ToString(), out id);
                                candidate.PartyId = id;

                                candidate.PartyName = reader["name"].ToString();

                                lst.Add(candidate);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public List<Candidate> Get()
        {
            return Collection("", "");
        }

        public Candidate Find(int candidateId)
        {
            var candidate = new Candidate();

            try
            {
                var lst = Collection("candidateId = " + candidateId.ToString(), "");

                if (lst.Count() == 1)
                {
                    candidate = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find candidate with candidateId = " + candidateId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return candidate;
        }

        public bool Exists(int candidateId, string first, string last)
        {
            bool exists = false;

            try
            {
                first.Replace("'", "\'");
                last.Replace("'", "\'");
                var lst = Collection("candidateId <> " + candidateId.ToString() + " AND firstName = '" + first + "' AND lastName = '" + last + "'", "");

                if (lst.Count() > 0)
                    exists = true;
                else
                    exists = false;

                Message = "";
                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return exists;
        }

        public bool Delete(int candidateId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM Candidates WHERE candidateId = @candidateId";

                        command.Parameters.AddWithValue("@candidateId", candidateId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Insert(Candidate candidate)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Candidates (firstName, lastName, partyId, description) VALUES (@firstName, @lastName, @partyId, @description)";

                        command.Parameters.AddWithValue("@firstName", candidate.FirstName);
                        command.Parameters.AddWithValue("@lastName", candidate.LastName);
                        command.Parameters.AddWithValue("@partyId", candidate.PartyId);
                        command.Parameters.AddWithValue("@description", candidate.Description);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(Candidate candidate)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE Candidates SET firstName = @firstName, lastName = @lastName, partyId = @partyId, description = @description WHERE candidateId = @candidateId";

                        command.Parameters.AddWithValue("@firstName", candidate.FirstName);
                        command.Parameters.AddWithValue("@lastName", candidate.LastName);
                        command.Parameters.AddWithValue("@partyId", candidate.PartyId);
                        command.Parameters.AddWithValue("@description", candidate.Description);
                        command.Parameters.AddWithValue("@candidateId", candidate.CandidateId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(Candidate candidate)
        {
            if (candidate.CandidateId == 0)
                return Insert(candidate);
            else
                return Update(candidate);
        }
    }
}