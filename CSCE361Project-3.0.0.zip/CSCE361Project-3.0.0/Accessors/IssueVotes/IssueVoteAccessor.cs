﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.IssueVotes
{
    public class IssueVoteAccessor : IIssueVoteAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public IssueVoteAccessor()
        {
            Message = "";
            Successful = false;
        }
        private List<IssueVote> Collection(string where, string orderby)
        {
            var lst = new List<IssueVote>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"SELECT issueVoteId, IV.issueId, I.name AS issueName, IV.vote, IV.userId, 
                                    U.firstName AS userFirstName, U.lastName AS userLastName, electionId
                                    FROM IssueVotes IV 
                                    left outer join Issues I on I.issueId = IV.issueId
                                    left outer join Users U on U.userId = IV.userId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var issueVote = new IssueVote();

                                int.TryParse(reader["issueVoteId"].ToString(), out id);
                                issueVote.IssueVoteId = id;

                                int.TryParse(reader["issueId"].ToString(), out id);
                                issueVote.IssueId = id;

                                issueVote.IssueName = reader["issueName"].ToString();

                                int.TryParse(reader["vote"].ToString(), out id);
                                issueVote.Vote = id;

                                int.TryParse(reader["userId"].ToString(), out id);
                                issueVote.UserId = id;

                                issueVote.UserName = reader["userFirstName"].ToString() + " " + reader["userLastName"].ToString();

                                int.TryParse(reader["electionId"].ToString(), out id);
                                issueVote.ElectionId = id;

                                lst.Add(issueVote);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public List<IssueVote> Get()
        {
            return Collection("", "");
        }

        public List<IssueVote> Get(int electionId)
        {
            return Collection("electionId = " + electionId.ToString(), "");
        }

        public List<IssueVote> Get(int userId, int electionId)
        {
            return Collection("IV.userId = " + userId.ToString() + " AND electionId = " + electionId.ToString(), "");
        }

        public IssueVote Find(int issueVoteId)
        {
            var iv = new IssueVote();

            try
            {
                var lst = Collection("issueVoteId = " + issueVoteId.ToString(), "");

                if (lst.Count() == 1)
                {
                    iv = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find an issue vote with issueVoteId = " + issueVoteId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return iv;
        }

        public bool Delete(int issueVoteId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM IssueVotes WHERE issueVoteId = @issueVoteId";

                        command.Parameters.AddWithValue("@issueVoteId", issueVoteId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Insert(IssueVote iv)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = @"INSERT INTO IssueVotes (issueId, vote, userId, electionId) 
                                                                   VALUES (@issueId, @vote, @userId, @electionId)";

                        command.Parameters.AddWithValue("@issueId", iv.IssueId);
                        command.Parameters.AddWithValue("@vote", iv.Vote);
                        command.Parameters.AddWithValue("@userId", iv.UserId);
                        command.Parameters.AddWithValue("@electionId", iv.ElectionId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(IssueVote iv)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = @"UPDATE IssueVotes SET issueId = @issueId, vote = @vote, userId = @userId
                                                    electionId = @electionId WHERE issueVoteId = @issueVoteId";

                        command.Parameters.AddWithValue("@issueId", iv.IssueId);
                        command.Parameters.AddWithValue("@vote", iv.Vote);
                        command.Parameters.AddWithValue("@userId", iv.UserId);
                        command.Parameters.AddWithValue("@electionId", iv.ElectionId);
                        command.Parameters.AddWithValue("@issueVoteId", iv.IssueVoteId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(IssueVote issueVote)
        {
            if (issueVote.IssueVoteId == 0)
                return Insert(issueVote);
            else
                return Update(issueVote);
        }
    }
}