﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;


namespace VotingApplication.Accessors.IssueVotes
{
    public interface IIssueVoteAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<IssueVote> Get();
        List<IssueVote> Get(int electionId);
        List<IssueVote> Get(int userId, int electionId);
        IssueVote Find(int issueVoteId);
        bool Delete(int issueVoteId);
        bool Save(IssueVote issueVote);
    }
}