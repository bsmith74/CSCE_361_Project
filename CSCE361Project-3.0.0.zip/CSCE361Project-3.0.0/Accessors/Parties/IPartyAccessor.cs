﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;


namespace VotingApplication.Accessors.Parties
{
    public interface IPartyAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<Party> Get();
        Party Find(int partyId);
        bool Exists(int partyId, string name);
        bool Delete(int partyId);
        bool Save(Party party);
    }
}