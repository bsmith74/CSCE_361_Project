﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Parties
{
    public class PartyAccessor : IPartyAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public PartyAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<Party> Collection(string where, string orderby)
        {
            var lst = new List<Party>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append("SELECT partyId, name FROM Party");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var party = new Party();

                                int.TryParse(reader["partyId"].ToString(), out id);
                                party.PartyId = id;

                                party.Name = reader["name"].ToString();

                                lst.Add(party);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public bool Delete(int partyId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM Party WHERE partyId = @partyId";

                        command.Parameters.AddWithValue("@partyId", partyId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public Party Find(int partyId)
        {
            var party = new Party();

            try
            {
                var lst = Collection("partyId = " + partyId.ToString(), "");

                if (lst.Count() == 1)
                {
                    party = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find party with partyId = " + partyId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return party;
        }

        public bool Exists(int partyId, string name)
        {
            bool exists = false;

            try
            {
                name.Replace("'", "\'");
                var lst = Collection("partyId <> " + partyId + " AND name = '" + name + "'", "");

                if (lst.Count > 0)
                    exists = true;
                else
                    exists = false;

                Message = "";
                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return exists;
        }

        public List<Party> Get()
        {
            return Collection("", "");
        }

        private bool Insert(Party party)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Party (name) VALUES (@name)";

                        command.Parameters.AddWithValue("@name", party.Name);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(Party party)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE Party SET name = @name WHERE partyId = @partyId";

                        command.Parameters.AddWithValue("@name", party.Name);
                        command.Parameters.AddWithValue("@partyId", party.PartyId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(Party party)
        {
            if (party.PartyId == 0)
                return Insert(party);
            else
                return Update(party);
        }
    }
}