﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Users
{
    public class UserAccessor : IUserAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public UserAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<User> Collection(string where, string orderby)
        {
            var lst = new List<User>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"SELECT Users.userId, firstName, lastName, username, password, R.roleId, R.name FROM Users
                                        LEFT OUTER JOIN UserRoles UR ON UR.userId = Users.userId
                                        LEFT OUTER JOIN Roles R ON R.roleId = UR.roleId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        var user = new User();

                        if (reader.HasRows)
                        {
                            int id;
                            int prevUserId = 0;
                            int currUserId = 0;

                            while (reader.Read())
                            {
                                int.TryParse(reader["userId"].ToString(), out id);

                                prevUserId = currUserId;
                                currUserId = id;
                                if (prevUserId == currUserId)
                                {
                                    var role = new Role();

                                    role.Name = reader["name"].ToString();

                                    int.TryParse(reader["roleId"].ToString(), out int roleId);
                                    role.RoleId = roleId;

                                    user.Roles.Add(role);
                                }
                                else
                                {
                                    if (prevUserId != 0)
                                        lst.Add(user);

                                    user = new User();

                                    user.UserId = id;

                                    user.FirstName = reader["firstName"].ToString();

                                    user.LastName = reader["lastName"].ToString();

                                    user.Username = reader["username"].ToString();

                                    user.Password = reader["password"].ToString();

                                    if (reader["name"] != DBNull.Value)
                                    {
                                        var role = new Role();

                                        role.Name = reader["name"].ToString();

                                        int.TryParse(reader["roleId"].ToString(), out int roleId);
                                        role.RoleId = roleId;

                                        user.Roles.Add(role);
                                    }
                                }
                            }

                            lst.Add(user);
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public List<User> Get()
        {
            return Collection("", "");
        }

        public User Find(int userId)
        {
            var user = new User();

            try
            {
                var lst = Collection("Users.userId = " + userId.ToString(), "");

                if (lst.Count() == 1)
                {
                    user = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find user with userId = " + userId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return user;
        }

        public User Find(string username)
        {
            var user = new User();

            try
            {
                username.Replace("'", "\'");
                var lst = Collection("username = '" + username + "'", "");

                if (lst.Count() == 1)
                {
                    user = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find user with username = " + username.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return user;
        }

        public bool Exists(int userId, string username)
        {
            User user = Find(username);

            // if no user exists with given username, return false
            if (user.UserId == 0)
                return false;
            else
            {
                // if the returned userid = given userid, then the
                // user is updating their account
                if (userId == user.UserId)
                    return false;

                // username exists and it is not the current user trying to update
                return true;
            }
        }

        public User Login(string username, string password)
        {
            var user = new User();

            try
            {
                username.Replace("'", "\'");
                password.Replace("'", "\'");
                var lst = Collection("username = '" + username + "' AND password = '" + password + "'", "");

                if (lst.Count() == 1)
                {
                    user = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find a user with the given credentials";
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return user;
        }

        public bool Delete(int userId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM Users WHERE userId = @userId";

                        command.Parameters.AddWithValue("@userId", userId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Insert(User user)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Users (firstName, lastName, username, password) VALUES (@firstName, @lastName, @username, @password)";

                        command.Parameters.AddWithValue("@firstName", user.FirstName);
                        command.Parameters.AddWithValue("@lastName", user.LastName);
                        command.Parameters.AddWithValue("@username", user.Username);
                        command.Parameters.AddWithValue("@password", user.Password);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(User user)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE Users SET firstName = @firstName, lastName = @lastName, username = @username, password = @password WHERE userId = @userId";

                        command.Parameters.AddWithValue("@firstName", user.FirstName);
                        command.Parameters.AddWithValue("@lastName", user.LastName);
                        command.Parameters.AddWithValue("@username", user.Username);
                        command.Parameters.AddWithValue("@password", user.Password);
                        command.Parameters.AddWithValue("@userId", user.UserId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(User user)
        {
            if (user.UserId == 0)
                return Insert(user);
            else
                return Update(user);
        }
    }
}