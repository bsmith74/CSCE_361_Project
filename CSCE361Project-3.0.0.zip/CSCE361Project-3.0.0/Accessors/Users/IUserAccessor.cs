﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Users
{
    public interface IUserAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<User> Get();
        User Find(int userId);
        User Find(string username);
        bool Exists(int userId, string username);
        User Login(string username, string password);
        bool Delete(int userId);
        bool Save(User user);
    }
}
