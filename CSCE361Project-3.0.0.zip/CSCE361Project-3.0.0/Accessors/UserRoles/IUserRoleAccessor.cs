﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VotingApplication.Accessors.UserRoles
{
    public interface IUserRoleAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        bool Delete(int userId);
        bool Insert(int userId, int roleId);
    }
}
