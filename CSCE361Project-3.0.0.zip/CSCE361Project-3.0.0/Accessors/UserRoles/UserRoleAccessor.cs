﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.Accessors.UserRoles
{
    public class UserRoleAccessor : IUserRoleAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public bool Delete(int userId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM UserRoles WHERE userId = @userId";

                        command.Parameters.AddWithValue("@userId", userId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        Message = "";
                        Successful = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Insert(int userId, int roleId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO UserRoles (userId, roleId) VALUES (@userId, @roleId)";

                        command.Parameters.AddWithValue("@userId", userId);
                        command.Parameters.AddWithValue("@roleId", roleId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }
    }
}