﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Roles
{
    public interface IRoleAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<Role> Get();
        Role Find(int roleId);
        bool Delete(int roleId);
        bool Save(Role role);
    }
}
