﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Results
{
    public interface IResultAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<IssueVote> GetIssue();
        List<IssueVote> GetIssue(int electionId);
        List<CandidatePosition> GetElectionResults(int electionId, List<Position> positions);
        int GetTotalIssueVotes(int electionId, int issueId);
    }
}
