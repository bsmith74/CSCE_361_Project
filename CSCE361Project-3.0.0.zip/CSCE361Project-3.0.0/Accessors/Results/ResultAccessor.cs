﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;
using VotingApplication.Accessors.IssueVotes;


namespace VotingApplication.Accessors.Results
{
    public class ResultAccessor : IResultAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public ResultAccessor()
        {
            Message = "";
            Successful = false;
        }

        private int TotalIssueVotes(string where, string groupby)
        {
            int total = 0;
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"SELECT count(issueVoteId) as votes
                                    FROM IssueVotes IV 
                                        left outer join Issues I on I.issueId = IV.issueId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(groupby))
                        query.Append(" GROUP BY " + groupby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                int.TryParse(reader["votes"].ToString(), out id); ;

                                total = id;
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }
            return total;
        }

        private List<IssueVote> IssueResults(string where, string groupby)
        {
            var lst = new List<IssueVote>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"SELECT issueVoteId, IV.issueId, I.name AS issueName, 
                                        electionId, sum(IV.vote) AS total, count(issueVoteId) as votes
                                    FROM IssueVotes IV 
                                        left outer join Issues I on I.issueId = IV.issueId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(groupby))
                        query.Append(" GROUP BY " + groupby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;
                            double total;
                            double percent;

                            while (reader.Read())
                            {
                                var issueResult = new IssueVote();

                                int.TryParse(reader["issueVoteId"].ToString(), out id);
                                issueResult.IssueVoteId = id;

                                int.TryParse(reader["issueId"].ToString(), out id);
                                issueResult.IssueId = id;

                                issueResult.IssueName = reader["issueName"].ToString();

                                int.TryParse(reader["electionId"].ToString(), out id);
                                issueResult.ElectionId = id;

                                double.TryParse(reader["total"].ToString(), out total);;

                                percent = total/GetTotalIssueVotes(issueResult.ElectionId, issueResult.IssueId);
                                if(percent > 0.5)
                                {
                                    issueResult.status = "Passed";

                                } else
                                {
                                    issueResult.status = "Rejected";
                                }
                                lst.Add(issueResult);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        private List<CandidatePosition> Winner(string where, string groupby, string orderby, string limit)
        {
            var winner = new List<CandidatePosition>();
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append(@"SELECT EV.positionId, P.name AS positionName, EV.candidateId, 
                                        C.firstName AS candidateFirstName, C.lastName AS candidateLastName, 
                                        EV.electionId, count(EV.candidateId) as total
                                    FROM ElectionVotes EV 
                                        left outer join Candidates C on C.candidateId = EV.candidateId
                                        left outer join Positions P on P.positionId = EV.positionId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(groupby))
                        query.Append(" GROUP BY " + groupby);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    if (!String.IsNullOrEmpty(limit))
                        query.Append(" LIMIT " + limit);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var result = new CandidatePosition();

                                int.TryParse(reader["positionId"].ToString(), out id);
                                result.PositionId = id;

                                result.PositionName = reader["positionName"].ToString();

                                int.TryParse(reader["candidateId"].ToString(), out id);
                                result.CandidateId = id;

                                result.CandidateName = reader["candidateFirstName"].ToString() + " " + reader["candidateLastName"].ToString();

                                int.TryParse(reader["electionId"].ToString(), out id);
                                result.ElectionId = id;

                                winner.Add(result);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }
            return winner;
        }

        public List<CandidatePosition> GetElectionResults(int electionId, List<Position> positions)
        {
            var lst = new List<CandidatePosition>();
            foreach(Position p in positions)
            {
                List<CandidatePosition> winners = new List<CandidatePosition>();
                if(p.Name != "Council Member")
                {
                    winners = Winner("EV.electionId = " + electionId.ToString() + " AND P.positionId = " + p.PositionId.ToString(),
                                                    "C.candidateId", "total DESC", "1");
                } else
                {
                    winners = Winner("EV.electionId = " + electionId.ToString() + " AND P.positionId = " + p.PositionId.ToString(),
                                                    "C.candidateId", "total DESC", "5");
                }
                
                foreach(CandidatePosition w in winners)
                {
                    lst.Add(w);
                }
            }

            Message = "";
            Successful = true;

            return lst;
        }

        public List<IssueVote> GetIssue()
        {
            return IssueResults("", "IV.issueId");
        }

        public List<IssueVote> GetIssue(int electionId)
        {
            return IssueResults("electionId = " + electionId.ToString(), "IV.issueId");
        }
        public int GetTotalIssueVotes(int electionId, int issueId)
        {
            return TotalIssueVotes("electionId = " + electionId.ToString() + "AND issueId = " + issueId.ToString(), "");
        }
    }
}