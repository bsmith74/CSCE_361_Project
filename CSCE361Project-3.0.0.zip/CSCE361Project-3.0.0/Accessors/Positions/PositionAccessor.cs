﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Positions
{
    public class PositionAccessor : IPositionAccessor
    {
        public string Message { get; set; }
        public bool Successful { get; set; }

        public PositionAccessor()
        {
            Message = "";
            Successful = false;
        }

        private List<Position> ElectionPositions(string where, string groupby)
        {
            var lst = new List<Position>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append("SELECT CP.positionId, P.name from CandidatePositions CP " +
                        "left outer join Elections E on E.electionId = CP.electionId " +
                        "left outer join Positions P on P.positionId = CP.positionId");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(groupby))
                        query.Append(" GROUP BY " + groupby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var position = new Position();

                                int.TryParse(reader["positionId"].ToString(), out id);
                                position.PositionId = id;

                                position.Name = reader["name"].ToString();

                                lst.Add(position);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        private List<Position> Collection(string where, string orderby)
        {
            var lst = new List<Position>();

            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    StringBuilder query = new StringBuilder();
                    query.Append("SELECT positionId, name FROM Positions");

                    if (!String.IsNullOrEmpty(where))
                        query.Append(" WHERE " + where);

                    if (!String.IsNullOrEmpty(orderby))
                        query.Append(" ORDER BY " + orderby);

                    using (var command = new MySqlCommand(query.ToString(), connection))
                    {
                        var reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            int id;

                            while (reader.Read())
                            {
                                var position = new Position();

                                int.TryParse(reader["positionId"].ToString(), out id);
                                position.PositionId = id;

                                position.Name = reader["name"].ToString();

                                lst.Add(position);
                            }
                        }

                        reader.Close();
                    }

                    connection.Close();
                }

                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return lst;
        }

        public bool Delete(int positionId)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "DELETE FROM Positions WHERE positionId = @positionId";

                        command.Parameters.AddWithValue("@positionId", positionId);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();
                        connection.Close();

                        if (validation == 1)
                        {
                            Message = "";
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records were removed from the database.";
                            Successful = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public Position Find(int positionId)
        {
            var position = new Position();

            try
            {
                var lst = Collection("positionId = " + positionId.ToString(), "");

                if (lst.Count() == 1)
                {
                    position = lst[0];

                    Message = "";
                    Successful = true;
                }
                else
                {
                    Message = "Did not find position with positionId = " + positionId.ToString();
                    Successful = false;
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return position;
        }

        public bool Exists(int positionId, string name)
        {
            bool exists = false;

            try
            {
                name.Replace("'", "\'");
                var lst = Collection("positionId <> " + positionId + " AND name = '" + name + "'", "");

                if (lst.Count > 0)
                    exists = true;
                else 
                    exists = false;

                Message = "";
                Successful = true;
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return exists;
        }

        public List<Position> Get()
        {
            return Collection("", "");
        }

        public List<Position> GetElectionPositions(int electionId)
        {
            return ElectionPositions("E.electionId = " + electionId.ToString(), "CP.positionId");
        }

        private bool Insert(Position position)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Positions (name) VALUES (@name)";

                        command.Parameters.AddWithValue("@name", position.Name);

                        connection.Open();
                        int validation = command.ExecuteNonQuery();

                        if (validation == 1)
                        {
                            long id = 0;

                            string query = "SELECT @@IDENTITY";

                            using (var command2 = new MySqlCommand(query, connection))
                            {
                                var reader = command2.ExecuteReader(System.Data.CommandBehavior.SingleResult);

                                while (reader.Read())
                                    long.TryParse(reader[0].ToString(), out id);

                                reader.Close();
                                command2.Dispose();
                            }

                            Message = id.ToString();
                            Successful = true;
                        }
                        else
                        {
                            Message = "No records added to the database.";
                            Successful = false;
                        }

                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        private bool Update(Position position)
        {
            try
            {
                string connectionString = "Data Source=cse.unl.edu;Initial Catalog=nhudson;User ID=nhudson;Password=0jzXBu8C";

                using (var connection = new MySqlConnection(connectionString))
                {
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = "UPDATE Positions SET name = @name WHERE positionId = @positionId";

                        command.Parameters.AddWithValue("@name", position.Name);
                        command.Parameters.AddWithValue("@positionId", position.PositionId);

                        connection.Open();
                        Successful = command.ExecuteNonQuery() == 1;
                        connection.Close();

                        if (!Successful)
                            Message = "No record updated in the database";
                    }
                }
            }
            catch (Exception ex)
            {
                Message = ex.Message;
                Successful = false;
            }

            return Successful;
        }

        public bool Save(Position position)
        {
            if (position.PositionId == 0)
                return Insert(position);
            else
                return Update(position);
        }
    }
}