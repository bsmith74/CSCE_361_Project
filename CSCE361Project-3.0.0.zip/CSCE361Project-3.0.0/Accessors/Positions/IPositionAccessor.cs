﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataContracts;

namespace VotingApplication.Accessors.Positions
{
    public interface IPositionAccessor
    {
        string Message { get; set; }
        bool Successful { get; set; }
        List<Position> Get();
        List<Position> GetElectionPositions(int electionId);
        Position Find(int positionId);
        bool Exists(int positionId, string name);
        bool Delete(int positionId);
        bool Save(Position position);
    }
}
