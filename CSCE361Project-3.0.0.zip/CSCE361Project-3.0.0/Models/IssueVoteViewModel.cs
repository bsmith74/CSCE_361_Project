﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class IssueVoteViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public IssueVoteDetailViewModel DetailViewModel { get; set; }
        public int ElectionId { get; set; }
        public List<Election> Elections { get; set; }

        public IssueVoteViewModel()
        {
            ErrorMessage = "";
            Error = false;

            DetailViewModel = new IssueVoteDetailViewModel();
            ElectionId = 0;
            Elections = new List<Election>();
        }
    }

    public class IssueVoteDetailViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }


        public int ElectionId { get; set; }
        public List<IssueVote> Votes { get; set; }

        public IssueVoteDetailViewModel()
        {
            ErrorMessage = "";
            Error = false;

            ElectionId = 0;
            Votes = new List<IssueVote>();
        }
    }

    public class IssueVoteDeleteViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int ElectionId { get; set; }
        public int IssueVoteId { get; set; }
        public int IssueId { get; set; }
        public string IssueName { get; set; }
        public int Vote { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }

        public IssueVoteDeleteViewModel()
        {
            ElectionId = 0;
            IssueVoteId = 0;
            IssueId = 0;
            IssueName = "";
            Vote = 0;
            UserId = 0;
            UserName = "";
        }
    }
}