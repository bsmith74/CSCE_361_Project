﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class CandidateViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public List<Candidate> Candidates { get; set; }

        public CandidateViewModel()
        {
            Error = false;
            ErrorMessage = "";

            Candidates = new List<Candidate>();
        }
    }

    public class CandidateUpdateViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int CandidateId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Description { get; set; }
        public int PartyId { get; set; }
        public string PartyName { get; set; }
        public List<Party> Parties { get; set; }

        public CandidateUpdateViewModel()
        {
            Error = false;
            ErrorMessage = "";

            CandidateId = 0;
            FirstName = "";
            LastName = "";
            Description = "";
            PartyId = 0;
            PartyName = "";
            Parties = new List<Party>();
        }
    }
}