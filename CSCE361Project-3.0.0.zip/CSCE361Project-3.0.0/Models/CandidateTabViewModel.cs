﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class CandidateTabListItem
    {
        public Candidate Candidate { get; set; }
        public List<Position> Positions { get; set; }

        public CandidateTabListItem()
        {
            Candidate = new Candidate();
            Positions = new List<Position>();
        }
    }

    public class CandidateTabViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int ElectionId { get; set; }
        public string ElectionName { get; set; }
        public List<CandidateTabListItem> Candidates { get; set; }

        public CandidateTabViewModel()
        {
            Error = false;
            ErrorMessage = "";

            ElectionId = 0;
            ElectionName = "";
            Candidates = new List<CandidateTabListItem>();
        }
    }
}