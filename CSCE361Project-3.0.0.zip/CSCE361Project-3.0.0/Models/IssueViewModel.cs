﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class IssueViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public List<Issue> Issues { get; set; }

        public IssueViewModel()
        {
            Error = false;
            ErrorMessage = "";

            Issues = new List<Issue>();
        }
    }

    public class IssueUpdateViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int IssueId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public IssueUpdateViewModel()
        {
            Error = false;
            ErrorMessage = "";

            IssueId = 0;
            Name = "";
            Description = "";
        }
    }
}