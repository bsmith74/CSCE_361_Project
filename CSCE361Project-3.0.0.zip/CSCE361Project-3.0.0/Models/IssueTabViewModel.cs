﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class IssueTabViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int ElectionId { get; set; }
        public string ElectionName { get; set; }
        public List<Issue> Issues { get; set; }

        public IssueTabViewModel()
        {
            Error = false;
            ErrorMessage = "";

            ElectionId = 0;
            ElectionName = "";
            Issues = new List<Issue>();
        }
    }
}