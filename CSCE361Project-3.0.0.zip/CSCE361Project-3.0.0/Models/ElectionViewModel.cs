﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class ElectionViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public List<Election> Elections { get; set; }

        public ElectionViewModel()
        {
            ErrorMessage = "";
            Error = false;

            Elections = new List<Election>();
        }
    }

    public class ElectionUpdateViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int ElectionId { get; set; }
        public string Name { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public ElectionUpdateViewModel()
        {
            ErrorMessage = "";
            Error = false;

            ElectionId = 0;
            Name = "";
            StartDate = new DateTime();
            EndDate = new DateTime();
        }
    }
}