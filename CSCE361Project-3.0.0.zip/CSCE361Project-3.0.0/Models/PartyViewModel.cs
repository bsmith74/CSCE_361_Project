﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class PartyViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public List<Party> Parties { get; set; }

        public PartyViewModel()
        {
            Error = false;
            ErrorMessage = "";

            Parties = new List<Party>();
        }
    }

    public class PartyUpdateViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int PartyId { get; set; }
        public string Name { get; set; }

        public PartyUpdateViewModel()
        {
            Error = false;
            ErrorMessage = "";

            PartyId = 0;
            Name = "";
        }
    }
}