﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class VoterVotedViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public VoterVotedDetailViewModel DetailViewModel { get; set; }
        public int ElectionId { get; set; }
        public List<Election> Elections { get; set; }

        public VoterVotedViewModel()
        {
            Error = false;
            ErrorMessage = "";

            DetailViewModel = new VoterVotedDetailViewModel();
            ElectionId = 0;
            Elections = new List<Election>();
        }
    }

    public class UserVotedListItem
    {
        public string UserName { get; set; }
        public bool Voted { get; set; }

        public UserVotedListItem()
        {
            UserName = "";
            Voted = false;
        }
    }

    public class VoterVotedDetailViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int ElectionId { get; set; }
        public List<UserVotedListItem> UserVotedListItems { get; set; }

        public VoterVotedDetailViewModel()
        {
            Error = false;
            ErrorMessage = "";

            ElectionId = 0;
            UserVotedListItems = new List<UserVotedListItem>();
        }
    }
}