﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class ElectionIssueViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int ElectionId { get; set; }
        public List<ElectionIssue> ElectionIssues { get; set; }

        public ElectionIssueViewModel()
        {
            ErrorMessage = "";
            Error = false;

            ElectionId = 0;
            ElectionIssues = new List<ElectionIssue>();
        }
    }

    public class ElectionIssueUpdateViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int ElectionId { get; set; }
        public int IssueId { get; set; }
        public List<Issue> Issues { get; set; }

        public ElectionIssueUpdateViewModel()
        {
            ErrorMessage = "";
            Error = false;

            ElectionId = 0;
            IssueId = 0;
            Issues = new List<Issue>();
        }
    }

    public class ElectionIssueDeleteViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int ElectionIssueId { get; set; }
        public string IssueName { get; set; }
        public int ElectionId { get; set; }

        public ElectionIssueDeleteViewModel()
        {
            ErrorMessage = "";
            Error = false;

            ElectionIssueId = 0;
            IssueName = "";
            ElectionId = 0;
        }
    }
}