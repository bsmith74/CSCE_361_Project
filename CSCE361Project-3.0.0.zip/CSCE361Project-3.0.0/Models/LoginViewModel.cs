﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace VotingApplication.Models
{
    public class LoginViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public string Username { get; set; }
        public string Password { get; set; }

        public LoginViewModel()
        {
            ErrorMessage = "";
            Error = false;

            Username = "";
            Password = "";
        }
    }

    public class CreateAccountViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }

        public CreateAccountViewModel()
        {
            ErrorMessage = "";
            Error = false;

            FirstName = "";
            LastName = "";
            Username = "";
            Password = "";
            ConfirmPassword = "";
        }
    }
}