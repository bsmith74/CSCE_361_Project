﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class CandidatePositionTableItem
    {
        public int CandidatePositionId { get; set; }
        public int CandidateId { get; set; }
        public string CandidateName { get; set; }
        public List<Position> Positions { get; set; }

        public CandidatePositionTableItem()
        {
            CandidatePositionId = 0;
            CandidateId = 0;
            CandidateName = "";
            Positions = new List<Position>();
        }
    }

    public class CandidatePositionViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int ElectionId { get; set; }
        public List<CandidatePositionTableItem> CandidatePositions { get; set; }

        public CandidatePositionViewModel()
        {
            ErrorMessage = "";
            Error = false;

            ElectionId = 0;
            CandidatePositions = new List<CandidatePositionTableItem>();
        }
    }

    public class PositionListItem
    {
        public Position Position { get; set; }
        public bool Selected { get; set; }

        public PositionListItem()
        {
            Position = new Position();
            Selected = false;
        }
    }

    public class CandidatePositionUpdateViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public bool Update { get; set; }
        public int ElectionId { get; set; }
        public int CandidateId { get; set; }
        public List<Candidate> Candidates { get; set; }
        public List<PositionListItem> Positions { get; set; }

        public CandidatePositionUpdateViewModel()
        {
            ErrorMessage = "";
            Error = false;

            Update = false;
            ElectionId = 0;
            CandidateId = 0;
            Candidates = new List<Candidate>();
            Positions = new List<PositionListItem>();
        }
    }

    public class CandidatePositionDeleteViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int ElectionId { get; set; }
        public int CandidateId { get; set; }
        public string CandidateName { get; set; }

        public CandidatePositionDeleteViewModel()
        {
            ErrorMessage = "";
            Error = false;

            ElectionId = 0;
            CandidateId = 0;
            CandidateName = "";
        }
    }
}