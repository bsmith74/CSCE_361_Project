﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class MyVotesViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int UserId { get; set; }
        public int ElectionId { get; set; }
        public List<Election> Elections { get; set; }
        public MyVotesDetailViewModel DetailViewModel { get; set; }

        public MyVotesViewModel()
        {
            Error = false;
            ErrorMessage = "";

            UserId = 0;
            ElectionId = 0;
            Elections = new List<Election>();
            DetailViewModel = new MyVotesDetailViewModel();
        }
    }

    public class MyVotesDetailViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int UserId { get; set; }
        public int ElectionId { get; set; }
        public List<ElectionVote> ElectionVotes { get; set; }
        public List<IssueVote> IssueVotes { get; set; }

        public MyVotesDetailViewModel()
        {
            Error = false;
            ErrorMessage = "";

            UserId = 0;
            ElectionId = 0;
            ElectionVotes = new List<ElectionVote>();
            IssueVotes = new List<IssueVote>();
        }
    }
}