﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class PositionViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public List<Position> Positions { get; set; }

        public PositionViewModel()
        {
            Error = false;
            ErrorMessage = "";

            Positions = new List<Position>();
        }
    }

    public class PositionUpdateViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int PositionId { get; set; }
        public string Name { get; set; }

        public PositionUpdateViewModel()
        {
            Error = false;
            ErrorMessage = "";

            PositionId = 0;
            Name = "";
        }
    }
}