﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class ElectionVoteViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public ElectionVoteDetailViewModel DetailViewModel { get; set; }
        public int ElectionId { get; set; }
        public List<Election> Elections { get; set; }

        public ElectionVoteViewModel()
        {
            ErrorMessage = "";
            Error = false;

            DetailViewModel = new ElectionVoteDetailViewModel();
            ElectionId = 0;
            Elections = new List<Election>();
        }
    }

    public class ElectionVoteDetailViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }


        public int ElectionId { get; set; }
        public List<ElectionVote> Votes { get; set; }

        public ElectionVoteDetailViewModel()
        {
            ErrorMessage = "";
            Error = false;

            ElectionId = 0;
            Votes = new List<ElectionVote>();
        }
    }

    public class ElectionVoteDeleteViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int ElectionId { get; set; }
        public int ElectionVoteId { get; set; }
        public int PositionId { get; set; }
        public string PositionName { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }

        public ElectionVoteDeleteViewModel()
        {
            ElectionId = 0;
            ElectionVoteId = 0;
            PositionId = 0;
            PositionName = "";
            UserId = 0;
            UserName = "";
        }
    }
}