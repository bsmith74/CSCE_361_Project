﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class ElectionPosition
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<ElectionCandidate> Candidates { get; set; }

        public ElectionPosition()
        {
            Id = 0;
            Name = "";
            Candidates = new List<ElectionCandidate>();
        }
    }

    public class ElectionCandidate
    {
        public CandidatePosition CandidatePosition { get; set; }
        public bool Checked { get; set; }

        public ElectionCandidate()
        {
            CandidatePosition = new CandidatePosition();
            Checked = false;
        }
    }

    public class ElectionIssueListItem
    {
        public ElectionIssue Issue { get; set; }
        public bool Checked { get; set; }

        public ElectionIssueListItem()
        {
            Issue = new ElectionIssue();
            Checked = false;
        }
    }

    public class VoteViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int UserId { get; set; }
        public int ElectionId { get; set; }
        public string ElectionName { get; set; }
        public bool UserVoted { get; set; }
        public List<ElectionPosition> Positions { get; set; }
        public List<ElectionIssueListItem> Issues { get; set; }

        public VoteViewModel()
        {
            Error = false;
            ErrorMessage = "";

            UserId = 0;
            ElectionId = 0;
            ElectionName = "";
            UserVoted = false;
            Positions = new List<ElectionPosition>();
            Issues = new List<ElectionIssueListItem>();
        }
    }
}