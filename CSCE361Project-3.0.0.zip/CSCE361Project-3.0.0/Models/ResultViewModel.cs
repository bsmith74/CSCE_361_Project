﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class ResultViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }
        public ResultDetailViewModel DetailViewModel { get; set; }

        public int ElectionId { get; set; }

        public List<Election> Elections { get; set; }


        public ResultViewModel()
        {
            ErrorMessage = "";
            Error = false;
            DetailViewModel = new ResultDetailViewModel();
            ElectionId = 0;
            Elections = new List<Election>();
        }
    }

    public class ResultDetailViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }
        public int ElectionId { get; set; }

        public List<Position> Positions { get; set; }
        public List<IssueVote> IssueResults { get; set; }
        public List<CandidatePosition> ElectionResults { get; set; }


        public ResultDetailViewModel()
        {
            ErrorMessage = "";
            Error = false;
            ElectionId = 0;
            Positions = new List<Position>();
            IssueResults = new List<IssueVote>();
            ElectionResults = new List<CandidatePosition>();
        }
    }
}