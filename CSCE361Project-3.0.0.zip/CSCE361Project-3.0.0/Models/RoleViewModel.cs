﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class RoleViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public List<Role> Roles { get; set; }

        public RoleViewModel()
        {
            ErrorMessage = "";
            Error = false;

            Roles = new List<Role>();
        }
    }

    public class RoleUpdateViewModel
    {
        public string ErrorMessage { get; set; }
        public bool Error { get; set; }

        public int RoleId { get; set; }
        public string Name { get; set; }

        public RoleUpdateViewModel()
        {
            ErrorMessage = "";
            Error = false;

            RoleId = 0;
            Name = "";
        }
    }
}