﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using VotingApplication.DataContracts;

namespace VotingApplication.Models
{
    public class UserViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public List<User> Users { get; set; }

        public UserViewModel()
        {
            Error = false;
            ErrorMessage = "";

            Users = new List<User>();
        }
    }

    public class RoleListItem
    {
        public Role Role { get; set; }
        public bool Selected { get; set; }

        public RoleListItem()
        {
            Role = new Role();
            Selected = false;
        }
    }

    public class UserUpdateViewModel
    {
        public bool Error { get; set; }
        public string ErrorMessage { get; set; }

        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public List<RoleListItem> Roles { get; set; }

        public UserUpdateViewModel()
        {
            Error = false;
            ErrorMessage = "";

            UserId = 0;
            FirstName = "";
            LastName = "";
            Username = "";
            Password = "";
            Roles = new List<RoleListItem>();
        }
    }
}