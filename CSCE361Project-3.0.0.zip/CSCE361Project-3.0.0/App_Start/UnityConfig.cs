﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using Unity;
using Unity.Mvc5;
using Unity.WebApi;
using VotingApplication.Accessors.Positions;
using VotingApplication.Accessors.Users;
using VotingApplication.Accessors.Parties;
using VotingApplication.Accessors.Issues;
using VotingApplication.Managers.Positions;
using VotingApplication.Managers.Users;
using VotingApplication.Managers.Parties;
using VotingApplication.Managers.Issues;
using VotingApplication.Accessors.Elections;
using VotingApplication.Managers.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Managers.ElectionVotes;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.Managers.IssueVotes;
using VotingApplication.Accessors.CandidatePositions;
using VotingApplication.Accessors.ElectionIssues;
using VotingApplication.Accessors.Candidates;
using VotingApplication.Managers.Candidates;
using VotingApplication.Authentication;
using VotingApplication.Accessors.Roles;
using VotingApplication.Managers.Roles;
using VotingApplication.Accessors.UserRoles;
using VotingApplication.Managers.MyVotes;
using VotingApplication.Managers.Results;
using VotingApplication.Accessors.Results;
using VotingApplication.Managers.Votes;
using VotingApplication.Managers.VoterVoted;

namespace VotingApplication.App_Start
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
            var container = new UnityContainer();

            //Users
            container.RegisterType<IUserManager, UserManager>();
            container.RegisterType<IUserAccessor, UserAccessor>();
            // UserRoles
            container.RegisterType<IUserRoleAccessor, UserRoleAccessor>();
            //Positions
            container.RegisterType<IPositionAccessor, PositionAccessor>();
            container.RegisterType<IPositionManager, PositionManager>();
            //Parties
            container.RegisterType<IPartyAccessor, PartyAccessor>();
            container.RegisterType<IPartyManager, PartyManager>();
            //Issues
            container.RegisterType<IIssueAccessor, IssueAccessor>();
            container.RegisterType<IIssueManager, IssueManager>();
            container.RegisterType<IIssueTabManager, IssueTabManager>();
            //Elections
            container.RegisterType<IElectionAccessor, ElectionAccessor>();
            container.RegisterType<IElectionManager, ElectionManager>();
            //CandidatePositions
            container.RegisterType<ICandidatePositionAccessor, CandidatePositionAccessor>();
            //ElectionIssues
            container.RegisterType<IElectionIssueAccessor, ElectionIssueAccessor>();
            //ElectionVotes
            container.RegisterType<IElectionVoteAccessor, ElectionVoteAccessor>();
            container.RegisterType<IElectionVoteManager, ElectionVoteManager>();
            //IssueVotes
            container.RegisterType<IIssueVoteAccessor, IssueVoteAccessor>();
            container.RegisterType<IIssueVoteManager, IssueVoteManager>();
            //Candidates
            container.RegisterType<ICandidateAccessor, CandidateAccessor>();
            container.RegisterType<ICandidateManager, CandidateManager>();
            container.RegisterType<ICandidateTabManager, CandidateTabManager>();
            //Roles
            container.RegisterType<IRoleAccessor, RoleAccessor>();
            container.RegisterType<IRoleManager, RoleManager>();
            
            
            //MyVotes
            container.RegisterType<IMyVoteManager, MyVoteManager>();
            //Votes
            container.RegisterType<IVoteManager, VoteManager>();
            //Results
            container.RegisterType<IResultAccessor, ResultAccessor>();
            container.RegisterType<IResultManager, ResultManager>();
            //VoterVoted
            container.RegisterType<IVoterVotedManager, VoterVotedManager>();

            DependencyResolver.SetResolver(new Unity.Mvc5.UnityDependencyResolver(container));
            GlobalConfiguration.Configuration.DependencyResolver = new Unity.WebApi.UnityDependencyResolver(container);
        }
    }
}