﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Managers.ElectionVotes;

namespace VotingApplication.Tests
{
    [TestClass]
    public class UnitTestElectionVoteManager
    {
        private IElectionVoteManager manager;

        public UnitTestElectionVoteManager()
        {
            manager = new ElectionVoteManager(new ElectionVoteAccessor(), new ElectionAccessor());
        }

        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            int electionId = 1;

            // Act
            var view = manager.DefaultView(electionId);

            // Assert
            Assert.AreEqual(electionId, view.ElectionId);
            Assert.IsTrue(view.Elections.Count > 0);
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_B_DetailView()
        {
            // Arrange
            int electionId = 1;

            // Act
            var view = manager.DetailView(electionId);

            // Assert
            Assert.AreEqual(electionId, view.ElectionId);
            Assert.IsTrue(view.Votes.Count == 0);
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_C_DeleteView()
        {
            // Arrange
            int electionVoteId = 2;
            int positionId = 1;
            int userId = 2;
            int electionId = 2;

            // Act
            var view = manager.DeleteView(electionVoteId);

            // Assert
            Assert.AreEqual(electionVoteId, view.ElectionVoteId);
            Assert.AreEqual(positionId, view.PositionId);
            Assert.AreEqual(userId, view.UserId);
            Assert.AreEqual(electionId, view.ElectionId);
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_D_Delete()
        {
            // Arrange
            int id = 0;

            // Act
            bool successful = manager.Delete(id);

            // Assert
            Assert.IsFalse(successful);
        }
    }
}
