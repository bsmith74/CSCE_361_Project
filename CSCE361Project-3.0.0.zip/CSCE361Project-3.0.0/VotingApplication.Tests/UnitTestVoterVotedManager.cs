﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.Accessors.Users;
using VotingApplication.Managers.VoterVoted;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Voter Voted Manager ****used non-specific tests for detail view***
    /// </summary>
    [TestClass]
    public class UnitTestVoterVotedManager
    {
        public UnitTestVoterVotedManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IVoterVotedManager manager;
            manager = new VoterVotedManager(new ElectionAccessor(), new UserAccessor(), new ElectionVoteAccessor(), new IssueVoteAccessor());

            // Act
            var view = manager.DefaultView(0);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_B_DetailView()
        {
            // Arrange
            IVoterVotedManager manager;
            manager = new VoterVotedManager(new ElectionAccessor(), new UserAccessor(), new ElectionVoteAccessor(), new IssueVoteAccessor());

            // Act
            var view = manager.DetailView(0);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }
    }
}

