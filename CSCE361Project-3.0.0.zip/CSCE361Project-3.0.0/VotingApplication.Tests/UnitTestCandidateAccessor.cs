﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Candidates;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Candidate Accessor 
    /// </summary>
    [TestClass]
    public class UnitTestCandidateAccessor
    {
        private ICandidateAccessor accessor { get; set; }

        public UnitTestCandidateAccessor()
        {
            accessor = new CandidateAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var firstName = "Pat";
            var fullName = "Pat Mann";
            var lastName = "Mann";
            var partyId = 3;
            var partyName = "Democrat";


            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].FirstName == firstName);
            Assert.IsTrue(lst[0].FullName == fullName);
            Assert.IsTrue(lst[0].LastName == lastName);
            Assert.IsTrue(lst[0].PartyId == partyId);
            Assert.IsTrue(lst[0].PartyName == partyName);
        }

        [TestMethod]
        public void Test_B_Find()
        {
            // Arrange
            DataContracts.Candidate candidate = new DataContracts.Candidate();
            candidate.CandidateId = 1;
            candidate.FirstName = "Pat";
            candidate.FullName = "Pat Mann";
            candidate.LastName = "Mann";
            candidate.PartyId = 3;
            candidate.PartyName = "Democrat";

            // Act
            var foundCandidate = accessor.Find(1);

            // Assert
            Assert.AreEqual(candidate.CandidateId, foundCandidate.CandidateId);
            Assert.AreEqual(candidate.FirstName, foundCandidate.FirstName);
            Assert.AreEqual(candidate.FullName, foundCandidate.FullName);
            Assert.AreEqual(candidate.LastName, foundCandidate.LastName);
            Assert.AreEqual(candidate.PartyId, foundCandidate.PartyId);
            Assert.AreEqual(candidate.PartyName, foundCandidate.PartyName);
        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            DataContracts.Candidate candidate = new DataContracts.Candidate();
            candidate.FirstName = "Test";
            candidate.FullName = "Test Candidate";
            candidate.LastName = "Candidate";
            candidate.PartyId = 3;
            candidate.PartyName = "Democrat";

            // Act
            accessor.Save(candidate);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.AreEqual(id, lst[lst.Count - 1].CandidateId);
            Assert.AreEqual(candidate.FirstName, lst[lst.Count - 1].FirstName);
            Assert.AreEqual(candidate.FullName, lst[lst.Count - 1].FullName);
            Assert.AreEqual(candidate.LastName, lst[lst.Count - 1].LastName);
            Assert.AreEqual(candidate.PartyId, lst[lst.Count - 1].PartyId);
            Assert.AreEqual(candidate.PartyName, lst[lst.Count - 1].PartyName);
        }

        [TestMethod]
        public void Test_D_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.Candidate candidate = new DataContracts.Candidate();
            candidate = lst[lst.Count - 1];

            // Act
            accessor.Delete(candidate.CandidateId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(candidate, lst2[lst2.Count - 1]);
        }

        [TestMethod]
        public void Test_E_Exists()
        {
            // Arrange
            var first = "Pat";
            var last = "Mann";

            // Act
            bool exists = accessor.Exists(0, first, last);

            // Assert
            Assert.IsTrue(exists);
        }
    }
}
