﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Elections;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Election Accessor 
    /// </summary>
    [TestClass]
    public class UnitTestElectionAccessor
    {
        private IElectionAccessor accessor { get; set; }

        public UnitTestElectionAccessor()
        {
            accessor = new ElectionAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var name = "First Election";
            var startDate = new DateTime(2021, 4, 24);
            var endDate = new DateTime(2021, 5, 24);

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].Name == name);
            Assert.IsTrue(lst[0].StartDate == startDate);
            Assert.IsTrue(lst[0].EndDate == endDate);
        }

        [TestMethod]
        public void Test_B_Find()
        {
            // Arrange
            DataContracts.Election election = new DataContracts.Election();
            election.ElectionId = 1;
            election.Name = "First Election";
            election.StartDate = new DateTime(2021,4,24);
            election.EndDate = new DateTime(2021, 5, 24);

            // Act
            var foundElection = accessor.Find(1);

            // Assert
            Assert.AreEqual(election.ElectionId, foundElection.ElectionId);
            Assert.AreEqual(election.Name, foundElection.Name);
            Assert.AreEqual(election.StartDate, foundElection.StartDate);
            Assert.AreEqual(election.EndDate, foundElection.EndDate);
        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            DataContracts.Election election = new DataContracts.Election();
            election.Name = "Test Election";
            election.StartDate = new DateTime(1111, 1, 1);
            election.EndDate = new DateTime(1111, 1, 1);

            // Act
            accessor.Save(election);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.AreEqual(id, lst[lst.Count - 1].ElectionId);
            Assert.AreEqual(election.Name, lst[lst.Count - 1].Name);
            Assert.AreEqual(election.StartDate, lst[lst.Count - 1].StartDate);
            Assert.AreEqual(election.StartDate, lst[lst.Count - 1].StartDate);
        }

        [TestMethod]
        public void Test_D_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.Election election = new DataContracts.Election();
            election = lst[lst.Count - 1];

            // Act
            accessor.Delete(election.ElectionId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(election, lst2[lst2.Count - 1]);
        }

        [TestMethod]
        public void Test_E_GetFinished()
        {
            // Act
            var lst = accessor.GetFinished();

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }

        [TestMethod]
        public void Test_F_FindCurrent()
        {
            // Arrange
            string date = "2021-04-25";
            DateTime.TryParse(date, out DateTime dt);

            // Act
            var election = accessor.FindCurrent(dt);

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.IsTrue(accessor.Successful);
            Assert.AreNotEqual(0, election.ElectionId);
        }

        [TestMethod]
        public void Test_G_Exists()
        {
            // Arrange
            string date1 = "2021-04-25";
            DateTime.TryParse(date1, out DateTime dt1);
            string date2 = "2021-04-26";
            DateTime.TryParse(date2, out DateTime dt2);

            // Act
            bool exists = accessor.Exists(0, dt1, dt2);

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.IsTrue(accessor.Successful);
            Assert.IsTrue(exists);
        }
    }
}
