﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.Managers.IssueVotes;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for IssueVote Manager ****Needs more work*****
    /// </summary>
    [TestClass]
    public class UnitTestIssueVoteManager
    {
        public UnitTestIssueVoteManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IIssueVoteManager manager;
            manager = new IssueVoteManager(new IssueVoteAccessor(), new ElectionAccessor());

            // Act
            var view = manager.DefaultView(1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_B_DetailView()
        {
            // Arrange
            IIssueVoteManager manager;
            manager = new IssueVoteManager(new IssueVoteAccessor(), new ElectionAccessor());

            // Act
            var view = manager.DetailView(1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
            Assert.AreEqual(1, view.ElectionId);
        }

        [TestMethod]
        public void Test_C_Delete()
        {
            // Arrange
            IIssueVoteManager manager;
            manager = new IssueVoteManager(new IssueVoteAccessor(), new ElectionAccessor());
            IIssueVoteAccessor accessor;
            accessor = new IssueVoteAccessor();

            accessor.Save(new DataContracts.IssueVote() { ElectionId = 1, IssueId = 1, UserId = 1, Vote = 0 });

            var lst = accessor.Get();
            var issueVote = lst[lst.Count - 1];

            // Act
            bool successful = manager.Delete(issueVote.IssueVoteId);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_D_DeleteView()
        {
            // Arrange
            IIssueVoteManager manager;
            manager = new IssueVoteManager(new IssueVoteAccessor(), new ElectionAccessor());

            // Act
            var view = manager.DeleteView(1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
            Assert.AreEqual(1, view.IssueVoteId);
        }
    }
}

