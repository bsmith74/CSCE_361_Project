﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.CandidatePositions;
using VotingApplication.Accessors.Candidates;
using VotingApplication.Accessors.ElectionIssues;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.Issues;
using VotingApplication.Accessors.Positions;
using VotingApplication.Managers.Elections;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Election Manager 
    /// </summary>
    [TestClass]
    public class UnitTestElectionManager
    {
        public UnitTestElectionManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var view = manager.DefaultView();

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_B_UpdateView()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            DataContracts.Election election = new DataContracts.Election();
            election.ElectionId = 1;
            election.Name = "First Election";
            election.StartDate = new DateTime(2021, 4, 24);
            election.EndDate = new DateTime(2021, 5, 24);

            // Act
            var view = manager.UpdateView(1);

            // Assert
            Assert.AreEqual(election.ElectionId, view.ElectionId);
            Assert.AreEqual(election.Name, view.Name);
            Assert.AreEqual(election.StartDate, view.StartDate);
            Assert.AreEqual(election.EndDate, view.EndDate);
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            DataContracts.Election election = new DataContracts.Election();
            election.Name = "Test Election";
            election.StartDate = new DateTime(1111, 1, 1);
            election.EndDate = new DateTime(1111, 2, 1);

            // Act
            bool successful = manager.Save(election);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_D_Exists()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            bool exists1 = manager.Exists(0, new DateTime(1111, 1, 1), new DateTime(1111, 2, 1));
            bool exists2 = manager.Exists(0, new DateTime(1111, 3, 1), new DateTime(1111, 4, 1));

            // Assert
            Assert.IsTrue(exists1);
            Assert.IsFalse(exists2);
        }

        [TestMethod]
        public void Test_E_Delete()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());
            IElectionAccessor accessor;
            accessor = new ElectionAccessor();

            var lst = accessor.Get();
            var election = lst[lst.Count - 1];

            // Act
            bool successful = manager.Delete(election.ElectionId);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_F_CandidatesView()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var view = manager.CandidatesView(1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
            Assert.AreEqual(view.ElectionId, 1);
        }

        [TestMethod]
        public void Test_G_CandidateUpdateView()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var view = manager.CandidateUpdateView(1, 0);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
            Assert.AreEqual(view.ElectionId, 1);
            Assert.AreEqual(view.CandidateId, 0);
            Assert.IsFalse(view.Update);
            Assert.IsTrue(view.Candidates.Count > 0);
            Assert.IsTrue(view.Positions.Count > 0);
        }

        [TestMethod]
        public void Test_H_SaveCandidate()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            bool successful = manager.SaveCandidate(new DataContracts.CandidatePosition()
            {
                CandidatePositionId = 0,
                CandidateId = 5,
                ElectionId = 1,
                PositionId = 1
            });

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_I_CandidateExists()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            bool exists = manager.CandidateExists(1, 5);

            // Assert
            Assert.IsTrue(exists);
        }

        [TestMethod]
        public void Test_J_CandidateDeleteView()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var view = manager.CandidateDeleteView(1, 5);

            // Assert
            Assert.AreEqual(view.ElectionId, 1);
            Assert.AreEqual(view.CandidateId, 5);
            Assert.AreEqual(view.CandidateName, "Test Candidate");
            Assert.IsFalse(view.Error);
            Assert.AreEqual(view.ErrorMessage, "");
        }

        [TestMethod]
        public void Test_K_DeleteCandidates()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            bool successful = manager.DeleteCandidates(1, 5);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_L_GetSelectedPositions()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var lst = manager.GetSelectedPositions(new List<int>());

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }

        [TestMethod]
        public void Test_M_GetPositions()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var lst = manager.GetPositions(1, 5);

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }

        [TestMethod]
        public void Test_M_GetCandidates()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var lst = manager.GetCandidates();

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }

        [TestMethod]
        public void Test_N_IssuesView()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var view = manager.IssuesView(1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual(view.ErrorMessage, "");
            Assert.AreEqual(view.ElectionId, 1);
            Assert.IsTrue(view.ElectionIssues.Count > 0);
        }

        [TestMethod]
        public void Test_O_IssueUpdateView()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var view = manager.IssueUpdateView(1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual(view.ErrorMessage, "");
            Assert.AreEqual(view.ElectionId, 1);
            Assert.IsTrue(view.Issues.Count > 0);
        }

        [TestMethod]
        public void Test_P_SaveIssue()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            bool successful = manager.SaveIssue(new DataContracts.ElectionIssue()
            {
                ElectionId = 1,
                IssueId = 6,
                ElectionIssueId = 0
            });

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_Q_IssueExists()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            bool exists = manager.IssueExists(1, 6);

            // Assert
            Assert.IsTrue(exists);
        }

        [TestMethod]
        public void Test_R_IssueDeleteView()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            IElectionIssueAccessor accessor;
            accessor = new ElectionIssueAccessor();
            var lst = accessor.Get(1);

            // Act
            var view = manager.IssueDeleteView(lst[lst.Count - 1].ElectionIssueId, 1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual(view.ErrorMessage, "");
            Assert.AreEqual(view.ElectionIssueId, lst[lst.Count - 1].ElectionIssueId);
        }

        [TestMethod]
        public void Test_S_DeleteIssue()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            IElectionIssueAccessor accessor;
            accessor = new ElectionIssueAccessor();
            var lst = accessor.Get(1);

            // Act
            bool successful = manager.DeleteIssue(lst[lst.Count - 1].ElectionIssueId);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_T_GetIssues()
        {
            // Arrange
            IElectionManager manager;
            manager = new ElectionManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new IssueAccessor(), new PositionAccessor(), new CandidateAccessor());

            // Act
            var lst = manager.GetIssues();

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }
    }
}
