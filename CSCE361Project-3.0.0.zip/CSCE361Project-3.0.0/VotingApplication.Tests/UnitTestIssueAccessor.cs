﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Issues;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Issues Accessor 
    /// </summary>
    [TestClass]
    public class UnitTestIssueAccessor
    {
        private IIssueAccessor accessor { get; set; }

        public UnitTestIssueAccessor()
        {
            accessor = new IssueAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var name = "Issue 1";
            var description = "Generic Issue Description";

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].Name == name);
            Assert.IsTrue(lst[0].Description == description);
        }

        [TestMethod]
        public void Test_B_Find()
        {
            // Arrange
            DataContracts.Issue issue = new DataContracts.Issue();
            issue.IssueId = 3;
            issue.Name = "Issue 1";
            issue.Description = "Generic Issue Description";

            // Act
            var foundIssue = accessor.Find(3);

            // Assert
            Assert.AreEqual(issue.IssueId, foundIssue.IssueId);
            Assert.AreEqual(issue.Name, foundIssue.Name);
            Assert.AreEqual(issue.Description, foundIssue.Description);
        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            DataContracts.Issue issue = new DataContracts.Issue();
            issue.Name = "Test Issue";
            issue.Description = "Test Issue Description";

            // Act
            accessor.Save(issue);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.AreEqual(id, lst[lst.Count - 1].IssueId);
            Assert.AreEqual(issue.Name, lst[lst.Count - 1].Name);
            Assert.AreEqual(issue.Description, lst[lst.Count - 1].Description);
        }

        [TestMethod]
        public void Test_D_Exists()
        {
            // Arrange
            string issue = "Test Issue";
            string desc = "Test Issue Description";

            // Act
            bool exists = accessor.Exists(0, issue, desc);

            // Assert
            Assert.IsTrue(exists);
        }

        [TestMethod]
        public void Test_E_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.Issue issue = new DataContracts.Issue();
            issue = lst[lst.Count - 1];

            // Act
            accessor.Delete(issue.IssueId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(issue, lst2[lst2.Count - 1]);
        }
    }
}
