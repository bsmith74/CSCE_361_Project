﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.ElectionIssues;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for ElectionIssue Accessor 
    /// </summary>
    [TestClass]
    public class UnitTestElectionIssueAccessor
    {
        private IElectionIssueAccessor accessor { get; set; }

        public UnitTestElectionIssueAccessor()
        {
            accessor = new ElectionIssueAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var issueId = 3;
            var electionIssueId = 1;
            var electionId = 1;

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].IssueId == issueId);
            Assert.IsTrue(lst[0].ElectionIssueId == electionIssueId);
            Assert.IsTrue(lst[0].ElectionId == electionId);
        }

        [TestMethod]
        public void Test_B_Get()
        {
            // Arrange
            var issueId = 3;
            var electionIssueId = 1;
            var electionId = 1;

            // Act
            var lst = accessor.Get(1);

            // Assert
            Assert.IsTrue(lst[0].IssueId == issueId);
            Assert.IsTrue(lst[0].ElectionIssueId == electionIssueId);
            Assert.IsTrue(lst[0].ElectionId == electionId);

        }

        [TestMethod]
        public void Test_C_Find()
        {
            // Arrange
            DataContracts.ElectionIssue electionIssue = new DataContracts.ElectionIssue();
            electionIssue.IssueId = 3;
            electionIssue.ElectionIssueId = 1;
            electionIssue.ElectionId = 1;

            // Act
            var foundElectionIssue = accessor.Find(1);

            // Assert
            Assert.AreEqual(electionIssue.IssueId, foundElectionIssue.IssueId);
            Assert.AreEqual(electionIssue.ElectionIssueId, foundElectionIssue.ElectionIssueId);
            Assert.AreEqual(electionIssue.ElectionId, foundElectionIssue.ElectionId);
        }

        [TestMethod]
        public void Test_D_Exists()
        {
            // Arrange
            var issueId = 3;
            var electionId = 1;

            // Act
            bool exists = accessor.Exists(electionId, issueId);

            // Assert
            Assert.AreEqual(true, exists);
        }

        [TestMethod]
        public void Test_E_Save()
        {
            // Arrange
            DataContracts.ElectionIssue electionIssue = new DataContracts.ElectionIssue();
            electionIssue.ElectionIssueId = 0;
            electionIssue.IssueId = 5;
            electionIssue.ElectionId = 1;

            // Act
            bool successful = accessor.Save(electionIssue);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(successful);
            Assert.AreEqual(id, lst[lst.Count - 1].ElectionIssueId);
        }

        [TestMethod]
        public void Test_F_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.ElectionIssue electionIssue = new DataContracts.ElectionIssue();
            electionIssue = lst[lst.Count - 1];

            // Act
            accessor.Delete(electionIssue.ElectionIssueId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(electionIssue, lst2[lst2.Count - 1]);
        }
    }
}
