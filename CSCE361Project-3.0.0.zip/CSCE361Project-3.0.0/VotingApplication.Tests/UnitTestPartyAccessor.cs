﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Parties;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Party Accessor
    /// </summary>
    [TestClass]
    public class UnitTestPartyAccessor
    {
        private IPartyAccessor accessor { get; set; }

        public UnitTestPartyAccessor()
        {
            accessor = new PartyAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var name = "Democrat";

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].Name == name);
        }

        [TestMethod]
        public void Test_B_Find()
        {
            // Arrange
            DataContracts.Party party = new DataContracts.Party();
            party.PartyId = 3;
            party.Name = "Democrat";

            // Act
            var foundParty = accessor.Find(3);

            // Assert
            Assert.AreEqual(party.PartyId, foundParty.PartyId);
            Assert.AreEqual(party.Name, foundParty.Name);
        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            DataContracts.Party party = new DataContracts.Party();
            party.Name = "Test Party";

            // Act
            accessor.Save(party);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.AreEqual(id, lst[lst.Count - 1].PartyId);
            Assert.AreEqual(party.Name, lst[lst.Count - 1].Name);
        }

        [TestMethod]
        public void Test_D_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.Party party = new DataContracts.Party();
            party = lst[lst.Count - 1];

            // Act
            accessor.Delete(party.PartyId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(party, lst2[lst2.Count - 1]);
        }

        [TestMethod]
        public void Test_E_Exists()
        {
            // Arrange
            string name = "Democrat";

            // Act
            bool exists = accessor.Exists(0, name);

            // Assert
            Assert.IsTrue(exists);
        }
    }
}
