﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Roles;
using VotingApplication.Accessors.UserRoles;
using VotingApplication.Accessors.Users;
using VotingApplication.DataContracts;
using VotingApplication.Managers.Users;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for User Manager 
    /// </summary>
    [TestClass]
    public class UnitTestUserManager
    {
        private IRoleAccessor roleAccessor { get; set; }
        public UnitTestUserManager()
        {
            roleAccessor = new RoleAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            DataContracts.User user = new DataContracts.User();
            user.UserId = 1;
            user.FirstName = "Noah";
            user.LastName = "Hudson";
            user.Username = "nhudson10";
            user.Password = "pa55w0rd";

            // Act
            var view = manager.DefaultView();

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_B_UpdateView()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            DataContracts.User user = new DataContracts.User();
            user.UserId = 1;
            user.FirstName = "Noah";
            user.LastName = "Hudson";
            user.Username = "nhudson10";
            user.Password = "pa55w0rd";

            // Act
            var view = manager.UpdateView(1);

            // Assert
            Assert.AreEqual(user.UserId, view.UserId);
            Assert.AreEqual(user.FirstName, view.FirstName);
            Assert.AreEqual(user.LastName, view.LastName);
            Assert.AreEqual(user.Username, view.Username);
            Assert.AreEqual(user.Password, view.Password);
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_C_Find()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            DataContracts.User user = new DataContracts.User();
            user.UserId = 1;
            user.FirstName = "Noah";
            user.LastName = "Hudson";
            user.Username = "nhudson10";
            user.Password = "pa55w0rd";

            // Act
            var id = manager.Find("nhudson10");

            // Assert
            Assert.AreEqual(user.UserId, id);
        }

        [TestMethod]
        public void Test_D_Exists()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            string username = "nhudson10";

            // Act
            bool exists = manager.Exists(0, username);

            // Assert
            Assert.AreEqual(true, exists);
        }

        [TestMethod]
        public void Test_E_Save()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            DataContracts.User user = new DataContracts.User();
            user.UserId = 0;
            user.FirstName = "Test";
            user.LastName = "User";
            user.Username = "testUser1";
            user.Password = "password";

            // Act
            bool successful = manager.Save(user);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_F_SaveRole()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            var userId = 9;
            var roleId = 2;

            // Act
            bool successful = manager.SaveRole(userId, roleId);
            // remove admin role from 'Some User', then add back user role
            IUserRoleAccessor userRoleAccessor = new UserRoleAccessor();
            userRoleAccessor.Delete(9);
            userRoleAccessor.Insert(9, 1);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_G_GetSelectedRoles()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            // Act
            var lst = manager.GetSelectedRoles(new List<int>());

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }

        [TestMethod]
        public void Test_H_GetRoles()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            // Act
            var lst = manager.GetRoles(1);

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }

        [TestMethod]
        public void Test_G_DeleteRole()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());

            var userId = 111;

            // Act
            bool successful = manager.DeleteRoles(userId);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_H_Delete()
        {
            // Arrange
            IUserManager manager;
            manager = new UserManager(new UserAccessor(), new RoleAccessor(), new UserRoleAccessor());
            IUserAccessor accessor;
            accessor = new UserAccessor();

            var lst = accessor.Get();
            var user = lst[lst.Count - 1];

            // Act
            bool successful = manager.Delete(user.UserId);

            // Assert
            Assert.IsTrue(successful);
        }


    }
}

