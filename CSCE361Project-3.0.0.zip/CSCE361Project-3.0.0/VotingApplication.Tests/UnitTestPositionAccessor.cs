﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Positions;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Positions Accessor 
    /// </summary>
    [TestClass]
    public class UnitTestPositionAccessor
    {
        private IPositionAccessor accessor { get; set; }

        public UnitTestPositionAccessor()
        {
            accessor = new PositionAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var name = "Mayor";

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].Name == name);
        }

        [TestMethod]
        public void Test_B_Find()
        {
            // Arrange
            DataContracts.Position position = new DataContracts.Position();
            position.PositionId = 1;
            position.Name = "Mayor";

            // Act
            var foundPosition = accessor.Find(1);

            // Assert
            Assert.AreEqual(position.PositionId, foundPosition.PositionId);
            Assert.AreEqual(position.Name, foundPosition.Name);
        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            DataContracts.Position position = new DataContracts.Position();
            position.Name = "Test Position";

            // Act
            bool successful = accessor.Save(position);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(successful);
            Assert.AreEqual(id, lst[lst.Count - 1].PositionId);
            Assert.AreEqual(position.Name, lst[lst.Count - 1].Name);
        }

        [TestMethod]
        public void Test_D_Exists()
        {
            // Arrange
            string pos = "Mayor";

            // Act
            bool exists = accessor.Exists(0, pos);

            // Assert
            Assert.IsTrue(exists);
        }

        [TestMethod]
        public void Test_E_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.Position position = new DataContracts.Position();
            position = lst[lst.Count - 1];

            // Act
            accessor.Delete(position.PositionId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(position, lst2[lst2.Count - 1]);
        }

        [TestMethod]
        public void Test_F_GetElectionPositions()
        {
            // Act
            var lst = accessor.GetElectionPositions(1);

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }
    }
}

