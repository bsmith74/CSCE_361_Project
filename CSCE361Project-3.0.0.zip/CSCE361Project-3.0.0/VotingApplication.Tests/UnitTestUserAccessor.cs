﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Users;
using VotingApplication.Accessors.Roles;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for User Accessor
    /// </summary>
    [TestClass]
    public class UnitTestUserAccessor
    {
        private IUserAccessor accessor { get; set; }
        private IRoleAccessor roleAccessor { get; set; }

        public UnitTestUserAccessor()
        {
            accessor = new UserAccessor();
            roleAccessor = new RoleAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var firstName = "Noah";
            var lastName = "Hudson";
            var password = "pa55w0rd";
            var userId = 1;
            var username = "nhudson10";

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].FirstName == firstName);
            Assert.IsTrue(lst[0].LastName == lastName);
            Assert.IsTrue(lst[0].Password == password);
            Assert.IsTrue(lst[0].UserId == userId);
            Assert.IsTrue(lst[0].Username == username);
        }

        [TestMethod]
        public void Test_B_FindUsingId()
        {
            // Arrange
            DataContracts.User user = new DataContracts.User();
            user.UserId = 1;
            user.FirstName = "Noah";
            user.LastName = "Hudson";
            user.Username = "nhudson10";
            user.Password = "pa55w0rd";

            // Act
            var foundUser = accessor.Find(1);

            // Assert
            Assert.AreEqual(user.UserId, foundUser.UserId);
            Assert.AreEqual(user.FirstName, foundUser.FirstName);
            Assert.AreEqual(user.LastName, foundUser.LastName);
            Assert.AreEqual(user.Username, foundUser.Username);
            Assert.AreEqual(user.Password, foundUser.Password);
        }

        [TestMethod]
        public void Test_C_FindUsingUsername()
        {
            // Arrange
            DataContracts.User user = new DataContracts.User();
            user.UserId = 1;
            user.FirstName = "Noah";
            user.LastName = "Hudson";
            user.Username = "nhudson10";
            user.Password = "pa55w0rd";

            // Act
            var foundUser = accessor.Find("nhudson10");

            // Assert
            Assert.AreEqual(user.UserId, foundUser.UserId);
            Assert.AreEqual(user.FirstName, foundUser.FirstName);
            Assert.AreEqual(user.LastName, foundUser.LastName);
            Assert.AreEqual(user.Username, foundUser.Username);
            Assert.AreEqual(user.Password, foundUser.Password);
        }

        [TestMethod]
        public void Test_D_Exists()
        {
            // Arrange
            var username = "nhudson10";

            // Act
            bool exists = accessor.Exists(0, username);

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.IsTrue(exists);
        }

        [TestMethod]
        public void Test_E_Login()
        {
            // Arrange
            DataContracts.User user = new DataContracts.User();
            user.UserId = 1;
            user.FirstName = "Noah";
            user.LastName = "Hudson";
            user.Username = "nhudson10";
            user.Password = "pa55w0rd";

            // Act
            var foundUser = accessor.Login("nhudson10", "pa55w0rd");

            // Assert
            Assert.AreEqual(user.UserId, foundUser.UserId);
            Assert.AreEqual(user.FirstName, foundUser.FirstName);
            Assert.AreEqual(user.LastName, foundUser.LastName);
            Assert.AreEqual(user.Username, foundUser.Username);
            Assert.AreEqual(user.Password, foundUser.Password);
        }

        [TestMethod]
        public void Test_F_Save()
        {
            // Arrange
            DataContracts.User user = new DataContracts.User();
            user.FirstName = "Test";
            user.LastName = "User";
            user.Username = "testUser1";
            user.Password = "password";

            // Act
            accessor.Save(user);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.AreEqual(id, lst[lst.Count - 1].UserId);
            Assert.AreEqual(user.FirstName, lst[lst.Count - 1].FirstName);
            Assert.AreEqual(user.LastName, lst[lst.Count - 1].LastName);
            Assert.AreEqual(user.Username, lst[lst.Count - 1].Username);
            Assert.AreEqual(user.Password, lst[lst.Count - 1].Password);
        }

        [TestMethod]
        public void Test_D_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.User user = new DataContracts.User();
            user = lst[lst.Count - 1];

            // Act
            accessor.Delete(user.UserId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(user, lst2[lst2.Count - 1]);
        }
    }
}

