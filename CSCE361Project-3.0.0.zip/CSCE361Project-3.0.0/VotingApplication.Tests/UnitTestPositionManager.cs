﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Positions;
using VotingApplication.Managers.Positions;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Positions Manager 
    /// </summary>
    [TestClass]
    public class UnitTestPositionManager
    {
        public UnitTestPositionManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IPositionManager manager;
            manager = new PositionManager(new PositionAccessor());

            DataContracts.Position position = new DataContracts.Position();
            position.PositionId = 1;
            position.Name = "Mayor";

            // Act
            var view = manager.DefaultView();

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_B_UpdateView()
        {
            // Arrange
            IPositionManager manager;
            manager = new PositionManager(new PositionAccessor());

            DataContracts.Position position = new DataContracts.Position();
            position.PositionId = 1;
            position.Name = "Mayor";

            // Act
            var view = manager.UpdateView(1);

            // Assert
            Assert.AreEqual(position.PositionId, view.PositionId);
            Assert.AreEqual(position.Name, view.Name);
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_C_Exists()
        {
            // Arrange
            IPositionManager manager;
            manager = new PositionManager(new PositionAccessor());

            string position = "Mayor";

            // Act
            bool exists = manager.Exists(0, position);

            // Assert
            Assert.AreEqual(true, exists);
        }

        [TestMethod]
        public void Test_D_Save()
        {
            // Arrange
            IPositionManager manager;
            manager = new PositionManager(new PositionAccessor());

            DataContracts.Position position = new DataContracts.Position();
            position.Name = "Test Position";

            // Act
            bool successful = manager.Save(position);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_E_Delete()
        {
            // Arrange
            IPositionManager manager;
            manager = new PositionManager(new PositionAccessor());
            IPositionAccessor accessor;
            accessor = new PositionAccessor();

            var lst = accessor.Get();
            var party = lst[lst.Count - 1];

            // Act
            bool successful = manager.Delete(party.PositionId);

            // Assert
            Assert.IsTrue(successful);
        }
    }
}

