﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.Managers.MyVotes;

namespace VotingApplication.Tests
{
    [TestClass]
    public class UnitTestMyVoteManager
    {
        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IMyVoteManager manager;
            manager = new MyVoteManager(new ElectionVoteAccessor(), new IssueVoteAccessor(), new ElectionAccessor());

            // Act
            var view = manager.DefaultView(1, 1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual(view.ErrorMessage, "");
            Assert.AreEqual(view.UserId, 1);
            Assert.AreEqual(view.ElectionId, 1);
            Assert.IsTrue(view.Elections.Count > 0);
        }

        [TestMethod]
        public void Test_A_DetailView()
        {
            // Arrange
            IMyVoteManager manager;
            manager = new MyVoteManager(new ElectionVoteAccessor(), new IssueVoteAccessor(), new ElectionAccessor());

            // Act
            var view = manager.DetailView(1, 1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual(view.ErrorMessage, "");
            Assert.AreEqual(view.UserId, 1);
            Assert.AreEqual(view.ElectionId, 1);
            Assert.IsTrue(view.IssueVotes.Count > 0);
            Assert.IsTrue(view.ElectionVotes.Count == 0);
        }
    }
}
