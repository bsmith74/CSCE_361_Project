﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VotingApplication.Accessors.ElectionVotes;

namespace VotingApplication.Tests
{
    [TestClass]
    public class UnitTestElectionVoteAccessor
    {
        private IElectionVoteAccessor accessor { get; set; }

        public UnitTestElectionVoteAccessor()
        {
            accessor = new ElectionVoteAccessor();
        }

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var electionVote = new DataContracts.ElectionVote()
            {
                ElectionVoteId = 2,
                PositionId = 1,
                CandidateId = 3,
                UserId = 2,
                ElectionId = 2
            };

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst.Count > 0);
            Assert.AreEqual(electionVote.ElectionVoteId, lst[0].ElectionVoteId);
            Assert.AreEqual(electionVote.PositionId, lst[0].PositionId);
            Assert.AreEqual(electionVote.CandidateId, lst[0].CandidateId);
            Assert.AreEqual(electionVote.UserId, lst[0].UserId);
            Assert.AreEqual(electionVote.ElectionId, lst[0].ElectionId);
        }

        [TestMethod]
        public void Test_B_Get()
        {
            // Arrange
            var electionVote = new DataContracts.ElectionVote()
            {
                ElectionVoteId = 2,
                PositionId = 1,
                CandidateId = 3,
                UserId = 2,
                ElectionId = 2
            };

            // Act
            var lst = accessor.Get(2);

            // Assert
            Assert.IsTrue(lst.Count == 1);
            Assert.AreEqual(electionVote.ElectionVoteId, lst[0].ElectionVoteId);
            Assert.AreEqual(electionVote.PositionId, lst[0].PositionId);
            Assert.AreEqual(electionVote.CandidateId, lst[0].CandidateId);
            Assert.AreEqual(electionVote.UserId, lst[0].UserId);
            Assert.AreEqual(electionVote.ElectionId, lst[0].ElectionId);
        }

        [TestMethod]
        public void Test_C_Get()
        {
            // Arrange
            var electionVote = new DataContracts.ElectionVote()
            {
                ElectionVoteId = 2,
                PositionId = 1,
                CandidateId = 3,
                UserId = 2,
                ElectionId = 2
            };

            // Act
            var lst = accessor.Get(2, 2);

            // Assert
            Assert.IsTrue(lst.Count == 1);
            Assert.AreEqual(electionVote.ElectionVoteId, lst[0].ElectionVoteId);
            Assert.AreEqual(electionVote.PositionId, lst[0].PositionId);
            Assert.AreEqual(electionVote.CandidateId, lst[0].CandidateId);
            Assert.AreEqual(electionVote.UserId, lst[0].UserId);
            Assert.AreEqual(electionVote.ElectionId, lst[0].ElectionId);
        }

        [TestMethod]
        public void Test_D_Find()
        {
            // Arrange
            var electionVote = new DataContracts.ElectionVote()
            {
                ElectionVoteId = 2,
                PositionId = 1,
                CandidateId = 3,
                UserId = 2,
                ElectionId = 2
            };

            // Act
            var vote = accessor.Find(2);

            // Assert
            Assert.IsTrue(vote.ElectionVoteId == 2);
            Assert.AreEqual(electionVote.ElectionVoteId, vote.ElectionVoteId);
            Assert.AreEqual(electionVote.PositionId, vote.PositionId);
            Assert.AreEqual(electionVote.CandidateId, vote.CandidateId);
            Assert.AreEqual(electionVote.UserId, vote.UserId);
            Assert.AreEqual(electionVote.ElectionId, vote.ElectionId);
        }

        [TestMethod]
        public void Test_E_Save()
        {
            // Arrange
            var electionVote = new DataContracts.ElectionVote()
            {
                ElectionVoteId = 0,
                ElectionId = 1,
                CandidateId = 1,
                PositionId = 1,
                UserId = 1
            };

            // Act
            var lst1 = accessor.Get();
            bool successful = accessor.Save(electionVote);
            var lst2 = accessor.Get();

            // Assert
            Assert.IsTrue(successful);
            Assert.AreEqual(lst1.Count, lst2.Count - 1);
        }

        [TestMethod]
        public void Test_F_Delete()
        {
            // Arrange
            var electionVote = new DataContracts.ElectionVote()
            {
                ElectionVoteId = 0,
                ElectionId = 1,
                CandidateId = 1,
                PositionId = 1,
                UserId = 1
            };

            // Act
            var lst = accessor.Get();
            bool successful = accessor.Delete(lst[lst.Count - 1].ElectionVoteId);
            var lst2 = accessor.Get();

            // Assert
            Assert.IsTrue(successful);
            Assert.AreEqual(lst.Count - 1, lst2.Count);
        }
    }
}
