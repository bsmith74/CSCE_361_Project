﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.IssueVotes;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for IssueVote Accessor ****Needs more work*****
    /// </summary>
    [TestClass]
    public class UnitTestIssueVoteAccessor
    {
        private IIssueVoteAccessor accessor { get; set; }

        public UnitTestIssueVoteAccessor()
        {
            accessor = new IssueVoteAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var userName = "Noah Hudson";
            var issueName = "Issue 1";
            var vote = 1;

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].UserName == userName);
            Assert.IsTrue(lst[0].IssueName == issueName);
            Assert.IsTrue(lst[0].Vote == vote);
        }

        [TestMethod]
        public void Test_B_Find()
        {
            // Arrange
            DataContracts.IssueVote issueVote = new DataContracts.IssueVote();
            issueVote.IssueVoteId = 1;
            issueVote.IssueId = 3;
            issueVote.IssueName = "Issue 1";
            issueVote.Vote = 1;
            issueVote.UserId = 1;
            issueVote.UserName = "Noah Hudson";
            issueVote.ElectionId = 1;

            // Act
            var foundIssueVote = accessor.Find(1);

            // Assert
            Assert.AreEqual(issueVote.IssueVoteId, foundIssueVote.IssueVoteId);
            Assert.AreEqual(issueVote.IssueId, foundIssueVote.IssueId);
            Assert.AreEqual(issueVote.IssueName, foundIssueVote.IssueName);
            Assert.AreEqual(issueVote.Vote, foundIssueVote.Vote);
            Assert.AreEqual(issueVote.UserId, foundIssueVote.UserId);
            Assert.AreEqual(issueVote.UserName, foundIssueVote.UserName);
            Assert.AreEqual(issueVote.ElectionId, foundIssueVote.ElectionId);

        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            DataContracts.IssueVote issueVote = new DataContracts.IssueVote();
            issueVote.IssueVoteId = 0;
            issueVote.IssueId = 6;
            issueVote.Vote = 0;
            issueVote.UserId = 1;
            issueVote.ElectionId = 1;

            // Act
            bool successful = accessor.Save(issueVote);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(successful);
            Assert.AreEqual(id, lst[lst.Count - 1].IssueVoteId);
        }

        [TestMethod]
        public void Test_D_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.IssueVote issueVote = new DataContracts.IssueVote();
            issueVote = lst[lst.Count - 1];

            // Act
            accessor.Delete(issueVote.IssueVoteId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(issueVote, lst2[lst2.Count - 1]);
        }

        [TestMethod]
        public void Test_E_Get()
        {
            // Act
            var lst = accessor.Get(1);

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }

        [TestMethod]
        public void Test_F_Get()
        {
            // Act
            var lst = accessor.Get(1, 1);

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }
    }
}
