﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Issues;
using VotingApplication.Managers.Issues;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Issue Manager 
    /// </summary>
    [TestClass]
    public class UnitTestIssueManager
    {
        public UnitTestIssueManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IIssueManager manager;
            manager = new IssueManager(new IssueAccessor());

            DataContracts.Issue issue = new DataContracts.Issue();
            issue.IssueId = 3;
            issue.Name = "Issue 1";
            issue.Description = "Generic Issue Description";

            // Act
            var view = manager.DefaultView();

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_B_UpdateView()
        {
            // Arrange
            IIssueManager manager;
            manager = new IssueManager(new IssueAccessor());

            DataContracts.Issue issue = new DataContracts.Issue();
            issue.IssueId = 3;
            issue.Name = "Issue 1";
            issue.Description = "Generic Issue Description";

            // Act
            var view = manager.UpdateView(3);

            // Assert
            Assert.AreEqual(issue.IssueId, view.IssueId);
            Assert.AreEqual(issue.Name, view.Name);
            Assert.AreEqual(issue.Description, view.Description);
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_C_Exists()
        {
            // Arrange
            IIssueManager manager;
            manager = new IssueManager(new IssueAccessor());

            // Act
            bool exists = manager.Exists(0, "Issue 1", "Generic Issue Description");

            // Assert
            Assert.AreEqual(true, exists);
        }

        [TestMethod]
        public void Test_D_Save()
        {
            // Arrange
            IIssueManager manager;
            manager = new IssueManager(new IssueAccessor());

            DataContracts.Issue issue = new DataContracts.Issue();
            issue.Name = "Test Issue";
            issue.Description = "Test Issue Description";

            // Act
            bool successful = manager.Save(issue);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_E_Delete()
        {
            // Arrange
            IIssueManager manager;
            manager = new IssueManager(new IssueAccessor());
            IIssueAccessor accessor;
            accessor = new IssueAccessor();

            var lst = accessor.Get();
            var issue = lst[lst.Count - 1];

            // Act
            bool successful = manager.Delete(issue.IssueId);

            // Assert
            Assert.IsTrue(successful);
        }
    }
}