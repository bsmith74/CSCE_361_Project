﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.UserRoles;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for UserRole Accessor ****doesnt have a get function, but did my best to test them without****
    /// </summary>
    [TestClass]
    public class UnitTestUserRoleAccessor
    {
        private IUserRoleAccessor accessor { get; set; }

        public UnitTestUserRoleAccessor()
        {
            accessor = new UserRoleAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Save()
        {
            // Arrange
            var userId = 9;
            var roleId = 2;

            // Act
            bool successful = accessor.Insert(userId, roleId);

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_B_Delete()
        {
            // Arrange
            var userId = 9;

            // Act
            bool successful = accessor.Delete(userId);
            // add user permission back to the user used for the test
            accessor.Insert(userId, 1);

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.IsTrue(successful);
        }
    }
}
