﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Roles;
using VotingApplication.Managers.Roles;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Roles Manager 
    /// </summary>
    [TestClass]
    public class UnitTestRoleManager
    {
        public UnitTestRoleManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IRoleManager manager;
            manager = new RoleManager(new RoleAccessor());

            DataContracts.Role role = new DataContracts.Role();
            role.RoleId = 1;
            role.Name = "User";

            // Act
            var view = manager.DefaultView();

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_B_UpdateView()
        {
            // Arrange
            IRoleManager manager;
            manager = new RoleManager(new RoleAccessor());

            DataContracts.Role role = new DataContracts.Role();
            role.RoleId = 1;
            role.Name = "User";

            // Act
            var view = manager.UpdateView(1);

            // Assert
            Assert.AreEqual(role.RoleId, view.RoleId);
            Assert.AreEqual(role.Name, view.Name);
            Assert.IsFalse(view.Error);
            Assert.AreEqual("", view.ErrorMessage);
        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            IRoleManager manager;
            manager = new RoleManager(new RoleAccessor());

            DataContracts.Role role = new DataContracts.Role();
            role.Name = "Test Role";

            // Act
            bool successful = manager.Save(role);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_D_Delete()
        {
            // Arrange
            IRoleManager manager;
            manager = new RoleManager(new RoleAccessor());
            IRoleAccessor accessor;
            accessor = new RoleAccessor();

            var lst = accessor.Get();
            var role = lst[lst.Count - 1];

            // Act
            bool successful = manager.Delete(role.RoleId);

            // Assert
            Assert.IsTrue(successful);
        }
    }
}
