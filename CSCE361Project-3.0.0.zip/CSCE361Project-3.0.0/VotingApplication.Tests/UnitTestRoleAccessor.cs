﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.Roles;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for Role Accessor 
    /// </summary>
    [TestClass]
    public class UnitTestRoleAccessor
    {
        private IRoleAccessor accessor { get; set; }

        public UnitTestRoleAccessor()
        {
            accessor = new RoleAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var name = "User";

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].Name == name);
        }

        [TestMethod]
        public void Test_B_Find()
        {
            // Arrange
            DataContracts.Role role = new DataContracts.Role();
            role.RoleId = 1;
            role.Name = "User";

            // Act
            var foundrole = accessor.Find(1);

            // Assert
            Assert.AreEqual(role.RoleId, foundrole.RoleId);
            Assert.AreEqual(role.Name, foundrole.Name);
        }

        [TestMethod]
        public void Test_C_Save()
        {
            // Arrange
            DataContracts.Role role = new DataContracts.Role();
            role.Name = "Test Role";

            // Act
            accessor.Save(role);
            string strId = accessor.Message;
            int.TryParse(strId, out int id);

            var lst = accessor.Get();

            // Assert
            Assert.AreEqual(id, lst[lst.Count - 1].RoleId);
            Assert.AreEqual(role.Name, lst[lst.Count - 1].Name);
        }

        [TestMethod]
        public void Test_D_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.Role role = new DataContracts.Role();
            role = lst[lst.Count - 1];

            // Act
            accessor.Delete(role.RoleId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(role, lst2[lst2.Count - 1]);
        }
    }
}
