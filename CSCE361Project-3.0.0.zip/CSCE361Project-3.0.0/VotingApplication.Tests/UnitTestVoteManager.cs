﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VotingApplication.Accessors.CandidatePositions;
using VotingApplication.Accessors.ElectionIssues;
using VotingApplication.Accessors.Elections;
using VotingApplication.Accessors.ElectionVotes;
using VotingApplication.Accessors.IssueVotes;
using VotingApplication.Managers.Votes;

namespace VotingApplication.Tests
{
    [TestClass]
    public class UnitTestVoteManager
    {
        [TestMethod]
        public void Test_A_DefaultView()
        {
            // Arrange
            IVoteManager manager;
            manager = new VoteManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new ElectionVoteAccessor(), new IssueVoteAccessor());

            // Act
            var view = manager.DefaultView(1);

            // Assert
            Assert.IsFalse(view.Error);
            Assert.AreEqual(view.ErrorMessage, "");
            Assert.AreEqual(view.UserId, 1);
        }

        [TestMethod]
        public void Test_B_GetPositions()
        {
            // Arrange
            IVoteManager manager;
            manager = new VoteManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new ElectionVoteAccessor(), new IssueVoteAccessor());

            // Act
            var lst = manager.GetPositions(1);

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }

        [TestMethod]
        public void Test_C_GetIssues()
        {
            // Arrange
            IVoteManager manager;
            manager = new VoteManager(new ElectionAccessor(), new CandidatePositionAccessor(), new ElectionIssueAccessor(), new ElectionVoteAccessor(), new IssueVoteAccessor());

            // Act
            var lst = manager.GetIssues(1);

            // Assert
            Assert.IsTrue(lst.Count > 0);
        }
    }
}
