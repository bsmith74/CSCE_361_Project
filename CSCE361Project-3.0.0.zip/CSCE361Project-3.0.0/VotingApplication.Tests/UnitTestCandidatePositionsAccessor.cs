﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using VotingApplication.Accessors.CandidatePositions;

namespace VotingApplication.Tests
{
    /// <summary>
    /// Unit tests for CandidatePosition Accessor 
    /// </summary>
    [TestClass]
    public class UnitTestCandidatePositionAccessor
    {
        private ICandidatePositionAccessor accessor { get; set; }

        public UnitTestCandidatePositionAccessor()
        {
            accessor = new CandidatePositionAccessor();
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_A_Get()
        {
            // Arrange
            var candidateId = 1;
            var candidatePositionId = 8;
            var electionId = 1;
            var positionId = 1;
            var positionName = "Mayor";

            // Act
            var lst = accessor.Get();

            // Assert
            Assert.IsTrue(lst[0].CandidateId == candidateId);
            Assert.IsTrue(lst[0].CandidatePositionId == candidatePositionId);
            Assert.IsTrue(lst[0].ElectionId == electionId);
            Assert.IsTrue(lst[0].PositionId == positionId);
            Assert.IsTrue(lst[0].PositionName == positionName);
        }

        [TestMethod]
        public void Test_B_Get()
        {
            // Arrange
            var candidateId = 1;
            var candidatePositionId = 33;
            var electionId = 8;
            var positionId = 1;

            // Act
            var lst = accessor.Get(electionId, candidateId);

            // Assert
            Assert.IsTrue(lst[0].CandidateId == candidateId);
            Assert.IsTrue(lst[0].CandidatePositionId == candidatePositionId);
            Assert.IsTrue(lst[0].ElectionId == electionId);
            Assert.IsTrue(lst[0].PositionId == positionId);
        }

        [TestMethod]
        public void Test_C_GetOrderedByCandidate()
        {
            // Arrange
            var candidateId = 1;
            var candidateName = "Pat Mann";
            var candidatePositionId = 33;
            var electionId = 8;
            var positionId = 1;
            var positionName = "Mayor";

            // Act
            var lst = accessor.GetOrderedByCandidate(8);

            // Assert
            Assert.IsTrue(lst[0].CandidateId == candidateId);
            Assert.IsTrue(lst[0].CandidateName == candidateName);
            Assert.IsTrue(lst[0].CandidatePositionId == candidatePositionId);
            Assert.IsTrue(lst[0].ElectionId == electionId);
            Assert.IsTrue(lst[0].PositionId == positionId);
            Assert.IsTrue(lst[0].PositionName == positionName);

        }

        [TestMethod]
        public void Test_D_GetOrderedByPosition()
        {
            // Arrange
            var candidateId = 3;
            var candidateName = "Dawn Keykong";
            var candidatePositionId = 29;
            var electionId = 8;
            var positionId = 1;
            var positionName = "Mayor";

            // Act
            var lst = accessor.GetOrderedByPosition(8);

            // Assert
            Assert.IsTrue(lst[0].CandidateId == candidateId);
            Assert.IsTrue(lst[0].CandidateName == candidateName);
            Assert.IsTrue(lst[0].CandidatePositionId == candidatePositionId);
            Assert.IsTrue(lst[0].ElectionId == electionId);
            Assert.IsTrue(lst[0].PositionId == positionId);
            Assert.IsTrue(lst[0].PositionName == positionName);

        }

        [TestMethod]
        public void Test_E_Exists()
        {
            // Arrange
            var candidateId = 1;
            var electionId = 8;

            // Act
            bool exists = accessor.Exists(electionId, candidateId);

            // Assert
            Assert.AreEqual(true, exists);
        }

        [TestMethod]
        public void Test_F_Save()
        {
            // Arrange
            DataContracts.CandidatePosition candidatePosition = new DataContracts.CandidatePosition();
            candidatePosition.CandidatePositionId = 0;
            candidatePosition.CandidateId = 5;
            candidatePosition.CandidateName = "Unit Test";
            candidatePosition.ElectionId = 8;
            candidatePosition.PositionId = 1;
            candidatePosition.PositionName = "Mayor";

            // Act
            bool successful = accessor.Save(candidatePosition);

            // Assert
            Assert.IsTrue(successful);
        }

        [TestMethod]
        public void Test_G_Delete()
        {
            // Arrange
            var lst = accessor.Get();

            DataContracts.CandidatePosition candidatePosition = new DataContracts.CandidatePosition();
            candidatePosition = lst[lst.Count - 1];

            // Act
            accessor.Delete(candidatePosition.CandidatePositionId);

            var lst2 = accessor.Get();

            // Assert
            Assert.AreEqual("", accessor.Message);
            Assert.AreNotEqual(candidatePosition, lst2[lst2.Count - 1]);
        }
    }
}

