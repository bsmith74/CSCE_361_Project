﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class CandidatePosition
    {
        public int CandidatePositionId { get; set; }
        public int ElectionId { get; set; }
        public int CandidateId { get; set; }
        public string CandidateName { get; set; }
        public int PositionId { get; set; }
        public string PositionName { get; set; }

        public CandidatePosition()
        {
            CandidatePositionId = 0;
            ElectionId = 0;
            CandidateId = 0;
            CandidateName = "";
            PositionId = 0;
            PositionName = "";
        }
    }
}