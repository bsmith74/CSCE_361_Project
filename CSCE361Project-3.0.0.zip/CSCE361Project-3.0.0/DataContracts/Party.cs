﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class Party
    {
        public int PartyId { get; set; }
        public string Name { get; set; }

        public Party()
        {
            PartyId = 0;
            Name = "";
        }
    }
}