﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class IssueVote
    {
        public int IssueVoteId { get; set; }
        public int IssueId { get; set; }
        public string IssueName { get; set; }
        public int Vote { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int ElectionId { get; set; }
        public string status { get; set; }
        public IssueVote()
        {
            IssueVoteId = 0;
            IssueId = 0;
            IssueName = "";
            Vote = 0;
            UserId = 0;
            UserName = "";
            ElectionId = 0;
            status = "";
        }
    }
}