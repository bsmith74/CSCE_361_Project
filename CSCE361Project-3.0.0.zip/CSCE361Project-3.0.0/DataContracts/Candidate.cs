﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class Candidate
    {
        public int CandidateId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName { get; set; }
        public string Description { get; set; }
        public int PartyId { get; set; }
        public string PartyName { get; set; }

        public Candidate()
        {
            CandidateId = 0;
            FirstName = "";
            LastName = "";
            FullName = "";
            Description = "";
            PartyId = 0;
            PartyName = "";
        }
    }
}