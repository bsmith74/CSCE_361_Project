﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class ElectionVote
    {
        public int ElectionVoteId { get; set; }
        public int PositionId { get; set; }
        public string PositionName { get; set; }
        public int CandidateId { get; set; }
        public string CandidateName { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int ElectionId { get; set; }
        public string total { get; set; }

        public ElectionVote()
        {
            ElectionVoteId = 0;
            PositionId = 0;
            PositionName = "";
            CandidateId = 0;
            CandidateName = "";
            UserId = 0;
            UserName = "";
            ElectionId = 0;
            total = "";
        }
    }
}