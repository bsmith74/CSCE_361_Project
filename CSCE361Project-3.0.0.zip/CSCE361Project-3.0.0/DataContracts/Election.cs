﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class Election
    {
        public int ElectionId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Name { get; set; }

        public Election()
        {
            ElectionId = 0;
            StartDate = new DateTime();
            EndDate = new DateTime();
            Name = "";
        }
    }
}