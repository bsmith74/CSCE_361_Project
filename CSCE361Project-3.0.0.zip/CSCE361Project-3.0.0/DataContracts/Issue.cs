﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class Issue
    {

        public int IssueId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public Issue()
        {
            IssueId = 0;
            Name = "";
            Description = "";
        }
    }
}