﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class ElectionIssue
    {
        public int ElectionIssueId { get; set; }
        public int ElectionId { get; set; }
        public int IssueId { get; set; }
        public string IssueName { get; set; }

        public ElectionIssue()
        {
            ElectionIssueId = 0;
            ElectionId = 0;
            IssueId = 0;
            IssueName = "";
        }
    }
}