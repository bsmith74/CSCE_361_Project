﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VotingApplication.DataContracts
{
    public class User
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public ICollection<Role> Roles { get; set; }

        public User()
        {
            UserId = 0;
            FirstName = "";
            LastName = "";
            Username = "";
            Password = "";
            Roles = new List<Role>();
        }
    }
}